library(shiny)
fluidRow(
  column(width = 2,div(class = "mean-row",
                       tags$button(tr("back"),id = "Back",type = "button",class = "btn btn-danger action-button glyphicon glyphicon-triangle-left btn-type btn-back"),
                       tags$hr(class = "div hr"),
                       h1(tr("choose questionaire element"),class = "modal-title"),
                       tags$hr(class = "div hr"),
                       actionButton("checkbox",tr("multiple choice"),class = "btn-type btn-checkbox"),
                       tags$br(),
                       tags$br(),
                       actionButton("RBn",tr("single choice"),class = "btn-type btn-radioButton"),
                       tags$br(),
                       tags$br(),
                       actionButton("numI",tr("num"),class = "btn-type btn-num"),
                       tags$br(),
                       tags$br(),
                       actionButton("TeI",tr("text"),class = "btn-type btn-text"),
                       tags$br(),
                       tags$br(),
                       actionButton("DaI",tr("date"),class = "btn-type btn-date"),
                       tags$br(),
                       tags$br(),
                       actionButton("SeI",tr("select"),class = "btn-type btn-select"),
                       tags$br(),
                       tags$br(),
                       actionButton("FA",tr("For Doctor"),class = "btn-type btn-forDoctor"),
                       
                       
                       
                       
  )),
  column(width = 5,div(class = "mean-make-middle-row",
                       uiOutput("Erstellen"),
                       uiOutput("Answer"),
                       tags$br(),
                       useShinyjs(),
                       conditionalPanel(
                         condition = "input.checkbox != 0",
                         tags$button(tr("create question"),id = "okay_checkbox",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),   
                       conditionalPanel(
                         condition = "input.RBn != 0",
                         tags$button(tr("create question"),id = "okay_RBn",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),
                       conditionalPanel(
                         condition = "input.numI != 0",
                         tags$button(tr("create question"),id = "okay_numI",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),
                       conditionalPanel(
                         condition = "input.TeI != 0",
                         tags$button(tr("create question"),id = "okay_TeI",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),
                       conditionalPanel(
                         condition = "input.DaI != 0",
                         tags$button(tr("create question"),id = "okay_DaI",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),
                       conditionalPanel(
                         condition = "input.SeI != 0",
                         tags$button(tr("create question"),id = "okay_SeI",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),
                       conditionalPanel(
                         condition = "input.FA != 0",
                         tags$button(tr("create question"),id = "okay_FA",type = "button",class = "btn btn-danger action-button btn-type btn-create"),
                       ),
                       conditionalPanel(
                         condition = "input.okay_checkbox != 0 || input.okay_RBn != 0 || input.okay_numI !=0 || input.okay_TeI != 0 || input.okay_DaI != 0 || input.okay_SeI != 0 || input.okay_FA != 0 ||input.alt != 0",
                         tags$button(tr("create question"),id = "okay_edit",type = "button",class = "btn btn-danger action-button btn-type btn-create"))
  )),
  
  column(width = 5,div(class = "mean-row",
                       h1(tr("Questionaire template"),class = "modal-title"),
                       tags$hr(class = "div hr"),
                       useShinyjs(),
                       h3(tr("Please enter the two question numbers to be exchanged:"),align = "right"),
                       div(style="display:inline-block;width: 100px"),
                       div(style="display:inline-block;width: 100px", numericInput("Snum1","Q1","0",min = 1,max = length(allQuestion),width = "50%")),
                       div(style="display:inline-block;width: 100px",numericInput("Snum2","Q2","0",min = 1,max = length(allQuestion),width = "50%")),
                       div(style="display:inline-block;width: ",actionButton("change1",tr("change"),icon = icon("sort"),class = "btn-type btn-change")),
                       tags$hr(class = "div hr"),
                       
                       fileInput("new",tr("upload Questionaire"),accept = c("application/json",
                                                                        "text/comma-separated-values,text/plain",
                                                                        ".json"),multiple = FALSE,placeholder = tr("No file selected")),
                       div(style="display:inline-block;width: 250px", actionButton("alt",tr("upload"),icon = icon("upload"),class = "btn-type btn-upload")),
                       div(style="display:inline-block;", downloadButton("Save",tr("save"),class = "btn-type btn-save")),
                       tags$br(),
                       tags$hr(class = "div hr"),
                       uiOutput("Fragenbogen"),
                       tags$hr(class = "div hr"),
                       tags$br(),
  )
  
  ))
