library(shiny)
library(shinyjs)
library(rmarkdown)
library(tidyverse)
library(ggplot2)
library(knitr)
library(gridExtra)
library(base64enc)
library(shinyBS)
library(jsonlite)
library(rjson)
library(rlist)
library(filesstrings)
library(extrafont)
library(shinyjqui)
library(shinyBS)
library(jpeg)
library(shinyWidgets)

source("Parser.R")

server <- function(input, output, session) {
  observeEvent(input$language, {
    update_lang(session, input$language)
  })
  
  ## translation function
  rownames(translation) <<- translation[, 1]
  tr <- function(text) {
    # translates text into current language
    sapply(text, function(s)
      translation[s, input$language], USE.NAMES = FALSE)
  }
  
  ## go to the questionaire
  observeEvent(input$btn_start, {
    updateNavbarPage(session, "navbar", "view")
  })
  
  # Jump from the start page to the analysis page
  observeEvent(input$btn_evalute, {
    updateNavbarPage(session, "navbar", "evalute")
  })
  
  # Jump from the start page to the make page
  observeEvent(input$btn_make, {
    updateNavbarPage(session, "navbar", "make")
  })
  
  # Back from the analysis page to start page
  observeEvent(input$back, {
    confirmation()
  })
  
  confirmation <- function() {
    ask_confirmation(
      inputId = "myconfirmation",
      title = NULL,
      text = tags$b(
        tr("If you leave before saving then your changes will be lost"),
        style = "color: #FA5858;"
      ),
      btn_labels = c(tr("cancel"), tr("exit")),
      btn_colors = c("#00BFFF", "#FE2E2E"),
      html = TRUE
    )
  }
  
  # Back from the make page to start page
  observeEvent(input$Back, {
    # output$page <- render_page(f = questionaire)
    confirmation()
  })
  
  # Back from the answer page to start page
  observeEvent(input$back2, {
    confirmation()
  })
  
  #cancle Button, wenn you want ro go back to the default page, show a Modal
  observeEvent(input$cancel, {
    confirmation()
  })
  
  # two vectors show Whether myconfirmation is true or false
  true <- reactiveVal(0)
  false <- reactiveVal(0)
  
  # Confirm to return to the default page
  observeEvent(input$myconfirmation, {
    if (isTRUE(input$myconfirmation)) {
      session$reload()
      output$page <- render_page(f = question_zero)
    } else {
      closeSweetAlert()
    }
  }, ignoreNULL = TRUE)
  
  # The UI Interface to Answer the Questionaire
  observeEvent(input$start, {
    output$page <- render_page(f = ViewQuestionaire)
  })
  
  # Data read from JSON file
  #
  # Returns:
  #   df1: JSON file data
  JsonDate <- reactive({
    if (is.null(input$NFile) && is.null(input$NFile1)) {
      return()
    }
    if (!is.null(input$NFile)) {
      inFile1 <- input$NFile
    }
    else if (!is.null(input$NFile1)) {
      inFile1 <- input$NFile1
    }
    df1 <- read_json(inFile1$datapath)
    return(df1)
  })
  
  # If the file storing the questionnaire is not imported, disable the forward button (go)
  observe({
    toggleState("start", !is.null(input$NFile))
  })
  
  ##########################################################survey format#################################################
  path <- function(img) {
    return(paste("background:url(", img, ")", sep = ""))
  }
  
  # AppCSS <- ".answer-image" = "{font-size:30px }"
  ##################################################Question type read###############################################
  QuestionRead <-  function(df1, Question, i) {
    a <- NULL
    imgs <- list()
    nAnswer <- NULL
    imgfiles <- NULL
    answer_img <- NULL
    for (j in seq(1:df1[[i]]$Answer_nr)) {
      a <- append(a, j)
      nAnswer <-
        append(nAnswer, df1[[i]]$Answer_Str[j]$Answer$Answer_name[1])
      if (!is.null(df1[[i]]$Answer_Str[j]$Answer$Image$path)) {
        answer_img <-
          img(
            src = paste(basename(
              df1[[i]]$Answer_Str[j]$Answer$Image$path
            ), sep = ""),
            width = paste(
              width = df1[[i]]$Answer_Str[j]$Answer$Image$size[2],
              "px",
              sep = ""
            ),
            height = paste(df1[[i]]$Answer_Str[j]$Answer$Image$size[1], "px", sep = ""),
            alt = df1[[i]]$Answer_Str[j]$Answer$Image$info,
            align = df1[[i]]$Answer_Str[j]$Answer$Image$position
          )
        imgs <- append(imgs, list(answer_img))
      }
    }
    if (!is.null(df1[[i]]$Img_Nr)) {
      for (j in seq(1:df1[[i]]$Img_Nr)) {
        imgfiles <- df1[[i]]$Img_paths
        imgs <-
          append(imgs, list(img(
            src = imgfiles[[j]], class = "img-view"
          )))
      }
    }
    Question <-
      append(Question, list(h4(paste(
        tr("question"), " ", i, sep = ""
      ))))
    if (names(df1[i]) == "Question_checkbox") {
      Question <-
        append(Question, list(
          div(
            class = "div inline-block",
            checkboxGroupInput(
              paste("QQuestion", i, sep = ""),
              df1[[i]]$question_name,
              choiceNames = nAnswer,
              choiceValues = a
            )
          ),
          div(class = "div inline block", imgs)
        ))
    }
    else if (names(df1[i]) == "Question_RBn") {
      Question <-
        append(Question, list(
          div(
            class = "div inline block",
            radioButtons(
              paste("QQuestion", i, sep = ""),
              df1[[i]]$question_name,
              choiceNames = nAnswer,
              choiceValues = a
            )
          ),
          div(class = "div inline block", imgs)
        ))
    }
    else if (names(df1[i]) == "Question_Select") {
      Question <-
        append(Question, list(
          div(class = "div inline block",
              selectInput(
                paste("QQuestion", i, sep = ""),
                df1[[i]]$question_name,
                a
              )),
          div(class = "div inline block", imgs)
        ))
    }
    else if (names(df1[i]) == "Question_num") {
      if (is.null(df1[[i]]$Answer_Str)) {
        Question <-
          append(Question, list(
            div(
              class = "div inline block",
              numericInput(
                paste("QQuestion", i, sep = ""),
                df1[[i]]$question_name,
                value = ""
              )
            ),
            div(class = "div inline block", imgs)
          ))
      } else{
        Question <-
          append(Question, list(
            div(
              class = "div inline block",
              numericInput(
                paste("QQuestion", i, sep = ""),
                df1[[i]]$question_name,
                min = df1[[i]]$Answer_Str[1],
                max = df1[[i]]$Answer_Str[2],
                value = ""
              )
            ),
            div(class = "div inline block", imgs)
          ))
      }
      Question <-
        append(Question, list(textOutput("Anweisung"),
                              tags$head(
                                tags$style(
                                  "#Anweisung{color: red; font-size: 20px; font-style: italic;}"
                                )
                              )))
    }
    else if (names(df1[i]) == "Question_text") {
      Question <-
        append(Question, list(
          div(class = "div inline block",
              textInput(
                paste("QQuestion", i, sep = ""),
                df1[[i]]$question_name,
                value = ""
              )),
          div(class = "div inline block", imgs)
        ))
    }
    else if (names(df1[i]) == "Question_date") {
      Question <-
        append(Question, list(
          div(class = "div inline block",
              dateInput(
                paste("QQuestion", i, sep = ""),
                df1[[i]]$question_name,
                value = NA
              )),
          div(class = "div inline block", imgs)
        ))
    }
    else if (names(df1[i]) == "Question_range") {
      a <- NULL
      nAnswer <- NULL
      len2 <- NULL
      answer_img <- NULL
      len <- df1[[i]]$Answer_nr
      a <- append(a, df1[[i]]$Answer_Str[[1]])
      if (len > 2) {
        len2 <- len - 2
        for (k in seq(1:len2)) {
          a <- append(a, "")
        }
      }
      a <- append(a, df1[[i]]$Answer_Str[[2]])
      for (j in seq(1:len)) {
        nAnswer <- append(nAnswer, j)
        # browser()
        if (!is.null(df1[[i]]$Answer_Str[j]$Answer$Image$path)) {
          answer_img <-
            img(
              src = paste(
                basename(df1[[i]]$Answer_Str[j]$Answer$Image$path),
                sep = ""
              ),
              width = paste(
                width = df1[[i]]$Answer_Str[j]$Answer$Image$size[2],
                "px",
                sep = ""
              ),
              height = paste(df1[[i]]$Answer_Str[j]$Answer$Image$size[1], "px", sep = ""),
              alt = df1[[i]]$Answer_Str[j]$Answer$Image$info,
              align = df1[[i]]$Answer_Str[j]$Answer$Image$position
            )
          imgs <- append(imgs, list(answer_img))
        }
      }
      Question <-
        append(Question, list(
          div(
            class = "div inline block",
            radioButtons(
              paste("QQuestion", i, sep = ""),
              df1[[i]]$question_name,
              choiceNames = a,
              choiceValues = nAnswer
            )
          ),
          div(class = "div inline block", imgs)
        ))
    }
    return(Question)
  }
  
  ###########################################Questionaire write####################################
  
  # Present different question with the forward button
  observeEvent(input$go, {
    if (input$go == 0 || is.null(input$go)) {
      return()
    }
    hide("confirm")
    hide("start")
    hide("NFile1")
    hide("Nsave")
    output$Q2 <- renderUI({
      input$go
      df1 <- JsonDate()
      inFile1 <- input$NFile
      inFile1 <- input$NFile1
      len <- length(df1)
      e <- input$go - input$goback
      for (i in seq(1:len)) {
        if (e == i) {
          Question <- vector("list", length = 20)
          Question <- QuestionRead(df1, Question, i)
          return(Question)
        }
        else if (e > len) {
          hide("go")
          hide("goback")
          show("Nsave")
          output$Q2 <- renderUI({
            tagList(
              h1("Questionaire is finished"),
              tags$img(
                src = "finish.png",
                height = "80%",
                width = "40%"
              )
            )
          })
        }
      }
    })
  })
  
  
  
  
  # Present different question with the Back button
  observeEvent(input$goback, {
    if (input$goback == 0 ||
        is.null(input$goback)) {
      return()
    }
    hide("confirm")
    hide("start")
    hide("NFile1")
    output$Q2 <- renderUI({
      input$goback
      df1 <- JsonDate()
      for (i in seq(1:length(df1))) {
        e <- input$go - input$goback
        if (e == 0) {
          output$Q2 <- renderUI({
            hide("goback")
            tagList(
              fileInput(
                "NFile1",
                "Please select the Questionnaire",
                accept = c(".json"),
                multiple = FALSE
              )
            )
          })
        }
        else if (e == i) {
          Question <- vector("list", length = 10)
          Question <- QuestionRead(df1, Question, i)
          return(Question)
        }
      }
    })
  })
  
  # Determine the current page and question
  j <- reactive({
    return(input$go - input$goback)
  })
  
  #check input is valid or not
  isValid_num <- reactive({
    if (names(JsonDate()[j()]) == "Question_num" &&
        !is.null(input[[paste("QQuestion", j(), sep = "")]]) &&
        !is.null(JsonDate()[[j()]]$Answer_Str)) {
      if (input[[paste("QQuestion", j(), sep = "")]] >= JsonDate()[[j()]]$Answer_Str[[1]] &&
          input[[paste("QQuestion", j(), sep = "")]] <= JsonDate()[[j()]]$Answer_Str[[2]]  &&
          !is.na(input[[paste("QQuestion", j(), sep = "")]])) {
        return(FALSE)
      }
      return(TRUE)
    }
  })
  
  output$Anweisung <- renderText({
    if (isTruthy(input[[paste("QQuestion", j(), sep = "")]]) == FALSE) {
      return()
    }
    if (isValid_num() == TRUE &&
        names(JsonDate()[j()]) == "Question_num") {
      tr("!Wrong value and please re-enter")
    }
    else{
      NULL
    }
  })
  
  # "weitere" button,can change options
  other <- reactive({
    t <- NULL
    len = length(JsonDate()[[j()]]$Answer_Str)
    for (i in seq(1:len)) {
      if (JsonDate()[[j()]]$Answer_Str[[i]] == "Sonstiges") {
        t = paste(i, sep = "")
      }
    }
    
    return(t)
  })
  
  # press the "weitere" button and the input box appears
  output$other <- renderUI({
    if (isTruthy(input[[paste("QQuestion", j(), sep = "")]]) == FALSE) {
      return()
    }
    if ("Sonstiges" %in% JsonDate()[[j()]]$Answer_Str[]) {
      if (input[[paste("QQuestion", j(), sep = "")]] == other()) {
        textInput(paste("other", j(), sep = ""), "", "")
      } else{
        return(NULL)
      }
    }
    
  })
  
  
  # to control the go and Back button,if unfilled,allow not to click
  observe({
    toggleState("go", isTruthy(input[[paste("QQuestion", j(), sep = "")]]) == TRUE)
  })
  
  observe({
    toggleState("go", isValid_num() == FALSE)
  })
  
  observe({
    toggleState("go", input$q8.1 != "" | is.null(input$q8.1))
  })
  
  observe({
    toggleState("go", input$q8.2 != "" | is.null(input$q8.2))
  })
  
  i <<- 0
  #################################################save data#############################################################
  
  # the questionnaire data for save
  q <- reactive({
    if (is.null(JsonDate()[[length(JsonDate())]]$question_name)) {
      len <- length(JsonDate()) - 1
    } else{
      len <- length(JsonDate())
    }
    Ndf <- data.frame(Q_0 = "0")
    print(Ndf)
    for (i in (1:len)) {
      a <- paste("Q_", i, sep = "")
      wert <- input[[paste("QQuestion", i, sep = "")]]
      c <- c(wert)
      d <- data.frame(t = c)
      names(d) = a
      Ndf <- cbind(Ndf, d)
      if ("Sonstiges" %in% JsonDate()[[i]]$Answer_Str) {
        if (!is.null(input[[paste("other", i, sep = "")]])) {
          a1 <- paste("Q_", i, "Sonstiges", sep = "")
          c1 <- c(a = input[[paste("other", i, sep = "")]])
          d1 <- data.frame(t = c1)
          names(d1) = a1
          Ndf <- cbind(Ndf, d1)
        }
        else{
          a2 <- paste("Q_", i, "Sonstiges", sep = "")
          c2 <- c(a = "Sonstiges")
          d2 <- data.frame(t = c2)
          names(d2) = a2
          Ndf <- cbind(Ndf, d2)
        }
      }
    }
    return(Ndf)
  })
  
  # save data in a csv file
  output$Nsave <- downloadHandler(
    filename = function() {
      paste(Sys.Date(), ".csv", sep = "")
    },
    content = function(file1) {
      write.csv(q(), file1, row.names = FALSE)
    }
  )
  
  
  #################################################Analyse Questionaire########################
  
  # get data from csv file
  Tdata <- reactive({
    inFile <- input$file
    if (is.null(inFile)) {
      return()
    }
    else{
      # view(inFile)
      numfiles = nrow(inFile)
      kata_csv1 = list()
      Tdata <- data.frame()
      for (i in 1:numfiles)
      {
        kata_csv1[[i]] = read.csv(inFile[[i, 'datapath']],
                                  header = TRUE,
                                  stringsAsFactors = FALSE)
        Tdata <- do.call(rbind, kata_csv1)
      }
      
      Tdata
    }
  })
  
  # read json file and get data
  Dtemplate <- function() {
    inFile <- input$file2
    if (inFile == "" || is.null(inFile)) {
      return()
    }
    if (!is.null(inFile)) {
      Tdf <- read_json(inFile$datapath)
    }
    
    return(Tdf)
  }
  
  # histodiagram
  TypeHistro <- function(j) {
    len <- length(Dtemplate()[[j]]$Answer_Str)
    data1 <- NULL
    for (u in seq(1:len)) {
      data1 <- append(data1, 0)
    }
    for (i in seq(1:len)) {
      if (!is.na(Tdata()[i, j + 1])) {
        a <- list()
        for (k in seq(1:len)) {
          a <- append(a, k)
        }
        for (k in seq(1:length(Tdata()[, j + 1]))) {
          if (Tdata()[k, j + 1] == Dtemplate()[[j]]$Answer_Str[[i]]) {
            data1[i] <- data1[i] + 1
          } else if (Tdata()[k, j + 1] %in% a) {
            data1 <- Tdata()[, j + 1]
          } else{
            data1[i] <- 0
          }
        }
      }
    }
    Tdf1 <- data.frame(data1)
    print(Tdf1)
    graph <- ggplot(Tdf1, aes(data1)) +
      geom_histogram(
        binwidth = 1,
        fill = "#69b3a2",
        color = "#e9ecef",
        alpha = 0.9
      ) +
      labs(
        x = tr("choice"),
        title = Dtemplate()[[j]]$question_name,
        y = tr("num")
      )
    
    return(graph)
  }
  
  # barplot
  Typebar <- function(j) {
    n <- NULL
    choice <- NULL
    print(Tdata())
    len <- length(Dtemplate()[[j]]$Answer_Str)
    if (len == 1 &&
        Dtemplate()[[j]]$Answer_Str[[1]] == "NA") {
      d1 <-
        Tdata()[which(Tdata()[, j + 1]  >= 14 &
                        Tdata()[, j + 1] <= 19), ]
      d2 <-
        Tdata()[which(Tdata()[, j + 1]  >= 20 &
                        Tdata()[, j + 1] <= 29), ]
      d3 <-
        Tdata()[which(Tdata()[, j + 1]  >= 30 &
                        Tdata()[, j + 1] <= 39), ]
      d4 <-
        Tdata()[which(Tdata()[, j + 1]  >= 40 &
                        Tdata()[, j + 1] <= 49), ]
      d5 <-
        Tdata()[which(Tdata()[, j + 1]  >= 50 &
                        Tdata()[, j + 1] <= 59), ]
      d6 <- Tdata()[which(Tdata()[, j + 1]  >= 60), ]
      n <- c(nrow(d1),
             nrow(d2),
             nrow(d3),
             nrow(d4),
             nrow(d5),
             nrow(d6))
      choice <-
        c("14~19", "20~29", "30~39", "40~49", "50~59", ">=60")
      Tdf1 <- data.frame(choice, n)
      graph <- ggplot(Tdf1, aes(x = choice, y = n)) +
        geom_bar(stat = 'identity', fill = "red") +
        labs(
          x = tr("choice"),
          title = Dtemplate()[[j]]$question_name,
          y = tr("num")
        ) +
        geom_text(aes(label = paste0(n)), nudge_y = 0.1)
    }
    else{
      choice <- NULL
      n <- NULL
      for (u in seq(1:len)) {
        n <- append(n, 0)
      }
      d <- 0
      for (i in seq(1:len)) {
        weiter <- paste("Q_", j, "Sonstiges", sep = "")
        if (!is.na(Tdata()[i, j + 1]) &&
            names(Tdata()[i]) != weiter) {
          a <- list()
          for (k in seq(1:len)) {
            a <- append(a, k)
          }
          for (k in seq(1:length(Tdata()[, j + 1]))) {
            if (Tdata()[k, j + 1] %in% a) {
              wert <- Tdata()[k, j + 1]
              n[wert] <- n[wert] + 1
            }
            else if (Tdata()[k, j + 1] %in% Dtemplate()[[j]]$Answer_Str[[i]]) {
              n[i] <- n[i] + 1
            }
            else{
              n[i] <- n[i]
            }
          }
        }
        else if (!is.na(Tdata()[i, j + 1]) &&
                 names(Tdata()[i]) == weiter) {
          wert1 <- Tdata()[i, j + 1]
          n[wert1] <- n[wert1] + 1
        }
        # choice <- Dtemplate()[[j]]$Answer_Str
        choice <-
          append(choice, Dtemplate()[[j]]$Answer_Str[[i]])
      }
      # print(n)
      Tdf1 <- data.frame(choice, n)
      graph <- ggplot(Tdf1, aes(x = choice, y = n)) +
        geom_bar(stat = 'identity', fill = "red") +
        labs(
          x = tr("choice"),
          title = Dtemplate()[[j]]$question_name,
          y = tr("num")
        ) +
        geom_text(aes(label = paste0(n)), nudge_y = 0.1)
    }
    
    
    return(graph)
  }
  
  # boxplot
  Typebox <- function(j) {
    n <- NULL
    choice <- NULL
    len <- length(Dtemplate()[[j]]$Answer_Str)
    if (len == 1 &&
        Dtemplate()[[j]]$Answer_Str[[1]] == "NA") {
      d1 <-
        Tdata()[which(Tdata()[, j + 1]  >= 14 &
                        Tdata()[, j + 1] <= 19), ]
      d2 <-
        Tdata()[which(Tdata()[, j + 1]  >= 20 &
                        Tdata()[, j + 1] <= 29), ]
      d3 <-
        Tdata()[which(Tdata()[, j + 1]  >= 30 &
                        Tdata()[, j + 1] <= 39), ]
      d4 <-
        Tdata()[which(Tdata()[, j + 1]  >= 40 &
                        Tdata()[, j + 1] <= 49), ]
      d5 <-
        Tdata()[which(Tdata()[, j + 1]  >= 50 &
                        Tdata()[, j + 1] <= 59), ]
      d6 <- Tdata()[which(Tdata()[, j + 1]  >= 60), ]
      n <- c(nrow(d1),
             nrow(d2),
             nrow(d3),
             nrow(d4),
             nrow(d5),
             nrow(d6))
      choice <-
        c("14~19", "20~29", "30~39", "40~49", "50~59", ">=60")
      Tdf1 <- data.frame(choice, n)
      graph <-
        ggplot(Tdf1, aes(x = choice,
                         y = n,
                         fill = choice)) +
        geom_boxplot() +
        labs(
          x = tr("choice"),
          title = Dtemplate()[[j]]$question_name,
          y = tr("num")
        ) +
        geom_text(aes(label = paste0(n)), nudge_y = 0.1)
    }
    else{
      choice <- NULL
      n <- NULL
      for (u in seq(1:len)) {
        n <- append(n, 0)
      }
      d <- 0
      for (i in seq(1:len)) {
        weiter <- paste("Q_", j, "Sonstiges", sep = "")
        if (!is.na(Tdata()[i, j + 1]) &&
            names(Tdata()[i]) != weiter) {
          a <- list()
          for (k in seq(1:len)) {
            a <- append(a, k)
          }
          for (k in seq(1:length(Tdata()[, j + 1]))) {
            if (Tdata()[k, j + 1] %in% a) {
              wert <- Tdata()[k, j + 1]
              n[wert] <- n[wert] + 1
            }
            else if (Tdata()[k, j + 1] %in% Dtemplate()[[j]]$Answer_Str[[i]]) {
              wert <- i
              n[wert] <- n[wert] + 1
            }
            else{
              n[i] <- n[i]
            }
          }
        }
        else if (!is.na(Tdata()[i, j + 1]) &&
                 names(Tdata()[i]) == weiter) {
          wert1 <- Tdata()[i, j + 1]
          n[wert1] <- n[wert1] + 1
        }
        # choice <- Dtemplate()[[j]]$Answer_Str
        choice <-
          append(choice, Dtemplate()[[j]]$Answer_Str[[i]])
      }
      Tdf1 <- data.frame(choice, n)
      graph <-
        ggplot(Tdf1, aes(x = choice,
                         y = n,
                         fill = choice)) +
        geom_boxplot() +
        labs(
          x = tr("choice"),
          title = Dtemplate()[[j]]$question_name,
          y = tr("rate")
        ) +
        geom_text(aes(label = paste0(n)), nudge_y = 0.1)
    }
    
    
    return(graph)
  }
  
  #Pie Chart
  TypePie <- function(j) {
    n <- NULL
    choice <- NULL
    len <- length(Dtemplate()[[j]]$Answer_Str)
    if (len == 1 &&
        Dtemplate()[[j]]$Answer_Str[[1]] == "NA") {
      d1 <-
        Tdata()[which(Tdata()[, j + 1]  >= 14 &
                        Tdata()[, j + 1] <= 19), ]
      d2 <-
        Tdata()[which(Tdata()[, j + 1]  >= 20 &
                        Tdata()[, j + 1] <= 29), ]
      d3 <-
        Tdata()[which(Tdata()[, j + 1]  >= 30 &
                        Tdata()[, j + 1] <= 39), ]
      d4 <-
        Tdata()[which(Tdata()[, j + 1]  >= 40 &
                        Tdata()[, j + 1] <= 49), ]
      d5 <-
        Tdata()[which(Tdata()[, j + 1]  >= 50 &
                        Tdata()[, j + 1] <= 59), ]
      d6 <- Tdata()[which(Tdata()[, j + 1]  >= 60), ]
      n <- c(nrow(d6),
             nrow(d1),
             nrow(d2),
             nrow(d3),
             nrow(d4),
             nrow(d5))
      choice <-
        c(">=60", "14~19", "20~29", "30~39", "40~49", "50~59")
      Tdf1 <- data.frame(n = n, choice = choice)
      label_value <-
        paste('(', round(n / sum(n) * 100, 1), '%)', sep = '')
      label <- paste(Tdf1$choice, label_value, sep = '')
      p <- ggplot(Tdf1, aes(x = "",
                            y = n,
                            fill = choice)) +
        geom_bar(stat = 'identity', width = 1)
      graph <- p + coord_polar(theta = 'y', start = 0) +
        labs(x = '',
             y = '',
             title = Dtemplate()[[j]]$question_name) +
        theme(axis.text = element_blank()) +
        theme(axis.ticks = element_blank()) +
        theme(legend.position = "none") +
        geom_text(aes(
          y = n / 10 + c(0, cumsum(n)[-length(n)]),
          x = sum(n) / 10,
          label = label
        ))
    }
    else{
      choice <- NULL
      n <- NULL
      for (u in seq(1:len)) {
        n <- append(n, 0)
      }
      d <- 0
      for (i in seq(1:len)) {
        weiter <- paste("Q_", j, "Sonstiges", sep = "")
        if (!is.na(Tdata()[i, j + 1]) &&
            names(Tdata()[i]) != weiter) {
          a <- list()
          for (k in seq(1:len)) {
            a <- append(a, k)
          }
          for (k in seq(1:length(Tdata()[, j + 1]))) {
            if (Tdata()[k, j + 1] %in% a) {
              wert <- Tdata()[k, j + 1]
              n[wert] <- n[wert] + 1
            }
            else if (Tdata()[k, j + 1] %in% Dtemplate()[[j]]$Answer_Str[[i]]) {
              wert <- i
              n[wert] <- n[wert] + 1
            }
            else{
              n[i] <- n[i]
            }
          }
        }
        else if (!is.na(Tdata()[i, j + 1]) &&
                 names(Tdata()[i]) == weiter) {
          wert1 <- Tdata()[i, j + 1]
          n[wert1] <- n[wert1] + 1
        }
        # choice <- Dtemplate()[[j]]$Answer_Str
        choice <-
          append(choice, Dtemplate()[[j]]$Answer_Str[[i]])
      }
      Tdf1 <- data.frame(choice, n)
      label_value <-
        paste('(', round(n / sum(n) * 100, 1), '%)', sep = '')
      label <- paste(Tdf1$choice, label_value, sep = '')
      graph <-
        ggplot(Tdf1, aes(
          x = tr("choice"),
          y = n,
          fill = choice
        )) +
        geom_bar(stat = 'identity',
                 position = 'stack',
                 width = 1) +
        coord_polar(theta = 'y') +
        labs(x = '',
             y = '',
             title = Dtemplate()[[j]]$question_name) +
        theme(axis.text = element_blank()) +
        theme(axis.ticks = element_blank()) +
        theme(legend.position = "none") +
        geom_text(aes(
          y = n / 10 + c(0, cumsum(n)[-length(n)]),
          x = sum(n) / 10,
          label = label
        ))
    }
    
    return(graph)
  }
  
  #Get the Number of charts
  tablecount <- reactive({
    j <- 0
    for (i in seq(1:length(Dtemplate()))) {
      j <- j + length(input[[paste("TQuestion", i, sep = "")]])
    }
    return(j)
  })
  
  # show question
  output$TypeQuestion <- renderUI({
    inFile <- input$file2
    if (inFile == "" || is.null(inFile)) {
      return()
    }
    if (!is.null(inFile)) {
      Tdf <- read_json(inFile$datapath)
    }
    tList <- list()
    for (i in seq(1:length(Tdf))) {
      if (Tdf[[i]]$data_type == "numeric") {
        tList <-
          append(tList, list(h5(
            paste(
              "Question ",
              i,
              " ",
              Tdf[[i]]$question_name,
              "--",
              Tdf[[i]]$data_type,
              sep = ""
            )
          )))
        tList <-
          append(tList, list(checkboxGroupInput(
            paste("TQuestion", i, sep = ""),
            tr("Please choose the type"),
            choices = c("barplot", "boxplot", "Histroplot", "pieplot")
          )))
      } else if (Tdf[[i]]$data_type == "non_numeric") {
        tList <-
          append(tList, list(h5(
            paste(
              "Question ",
              i,
              "-",
              Tdf[[i]]$question_name,
              " -",
              Tdf[[i]]$data_type,
              sep = ""
            )
          )))
      }
    }
    return(tList)
  })
  
  # expand or reduce the scope of presentation
  output$AllTabelle <- renderUI({
    if (tablecount() == 0) {
      return(NULL)
    }
    jqui_resizable(plotOutput("AllTabelle1", width = "100%", height = {
      paste(300 * tablecount(), "px", sep = "")
    }))
  })
  
  # show diagram
  output$AllTabelle1 <- renderPlot({
    inFile1 <- input$file
    if (is.null(inFile1)) {
      return()
    }
    inFile2 <- input$file2
    if (is.null(inFile2)) {
      return()
    }
    if (!is.null(inFile2)) {
      Tdf <- read_json(inFile2$datapath)
    }
    value <- NULL
    plot_list <<- list()
    for (i in seq(1:length(Tdf))) {
      if ("Histroplot" %in% input[[paste("TQuestion", i, sep = "")]]) {
        plot_list <<- append(plot_list, list(TypeHistro(i)))
      }
      if ("barplot" %in% input[[paste("TQuestion", i, sep = "")]]) {
        plot_list <<- append(plot_list, list(Typebar(i)))
      }
      if ("boxplot" %in% input[[paste("TQuestion", i, sep = "")]]) {
        plot_list <<- append(plot_list, list(Typebox(i)))
      }
      if ("pieplot" %in% input[[paste("TQuestion", i, sep = "")]]) {
        plot_list <<- append(plot_list, list(TypePie(i)))
      }
    }
    if (length(plot_list) < 1) {
      return()
    }
    else{
      grid.arrange(grobs = plot_list)
    }
  })
  
  # get the selected chart
  plot_data <- reactive({
    return(plot_list)
  })
  
  # All Table save as pdf
  output$downloadAll <- downloadHandler(
    filename = "Allreport.pdf",
    content = function(file) {
      src <- normalizePath('Allreport.Rmd')
      owd <- setwd(tempdir())
      on.exit(setwd(owd))
      file.copy(src, 'Allreport.Rmd', overwrite = TRUE)
      
      library(rmarkdown)
      Td1 <- Dtemplate()
      my.data <- Tdata()
      out <- rmarkdown::render(
        'Allreport.Rmd',
        output_file = file,
        params = list(Td = Td1,
                      tdata1 = my.data),
        envir = new.env(parent = globalenv())
      )
      file.rename(out, file)
    }
  )
  
  
  # only selected Table save as pdf
  output$download <- downloadHandler(
    filename = "report2.pdf",
    content = function(file) {
      # src <- normalizePath('Allreport.Rmd')
      # owd <- setwd(tempdir())
      # on.exit(setwd(owd))
      tempReport <- file.path(tempdir(), "report2.Rmd")
      file.copy("report2.Rmd", tempReport, overwrite = TRUE)
      
      my.value <- plot_data()
      out <- rmarkdown::render(
        tempReport,
        output_file = file,
        params = list(value1 = my.value),
        envir = new.env(parent = globalenv())
      )
      file.rename(out, file)
    }
  )
  
  #############################################Make Questionaire####################################
  
  # get the num of question
  get_submit_num <- reactive({
    sub <-
      as.numeric(input$okay_checkbox) + as.numeric(input$okay_RBn) + as.numeric(input$okay_numI) +
      as.numeric(input$okay_TeI) + as.numeric(input$okay_SeI) + as.numeric(input$okay_Range) + as.numeric(input$okay_DaI) + as.numeric(input$okay_LK) + as.numeric(input$okay_Group)
    return(sub)
  })
  
  # List for produced question
  Dtype <<- list()
  
  ################################################different question exchange##########################################
  changeQuestion <- function(i) {
    if (is.null(input[[paste("type", i, sep = "")]])) {
      return(NULL)
    }
    if (input[[paste("type", i, sep = "")]] == "Multiple" ||
        input[[paste("type", i, sep = "")]] == "Single" ||
        input[[paste("type", i, sep = "")]] == "Select") {
      tagList(
        uiOutput(paste("answer", i, sep = "")),
        checkboxInput(paste("sonstige", i, sep = ""), "Sonstige Choice", value = FALSE),
        actionButton(paste("add", i, ""), "add choice", icon = icon("plus")),
        fileInput(
          paste("myFile", i, sep = ""),
          tr("Insert picture"),
          multiple = TRUE,
          accept = c('image/png', 'image/jpeg'),
          width = "70%",
          placeholder = tr("No file selected")
        )
      )
    } else if (input[[paste("type", i, sep = "")]] == "Nummer") {
      tagList(
        div(style = "display:inline-block;100px",
            numericInput(
              paste("range1_", i, sep = ""),
              tr("from"),
              value = "",
              width = "30%"
            )),
        div(style = "display:inline-block;",
            numericInput(
              paste("range2_", i, sep = ""),
              tr("to"),
              value = "",
              width = "30%"
            )),
        fileInput(
          paste("myFile", i, sep = ""),
          tr("Insert picture"),
          multiple = TRUE,
          accept = c('image/png', 'image/jpeg'),
          width = "70%",
          placeholder = tr("No file selected")
        )
      )
    } else if (input[[paste("type", i, sep = "")]] == "Range") {
      tagList(
        textInput(
          paste("range1", i, sep = ""),
          "range1",
          value = "",
          width = "50%"
        ),
        textInput(
          paste("range2", i, sep = ""),
          "range2",
          value = "",
          width = "50%"
        ),
        numericInput(
          paste("Answernum-", i, sep = ""),
          paste("please enter the range size"),
          value = 2,
          width = "20%",
          min = 2,
          max = 10
        ),
        checkboxInput(
          paste("sonstige", i, sep = ""),
          tr("Sonstige Choice"),
          value = FALSE
        ),
        fileInput(
          paste("myFile", i, sep = ""),
          tr("Insert picture"),
          multiple = TRUE,
          accept = c('image/png', 'image/jpeg'),
          width = "70%",
          placeholder = tr("No file selected")
        )
      )
    }
    else if (input[[paste("type", i, sep = "")]] == "Text" ||
             input[[paste("type", i, sep = "")]] == "Date") {
      fileInput(
        paste("myFile", i, sep = ""),
        tr("Insert picture"),
        multiple = TRUE,
        accept = c('image/png', 'image/jpeg'),
        width = "70%",
        placeholder = tr("No file selected")
      )
    }
  }
  
  #############################################Multiple question####################################
  checkbox <<- NULL
  observeEvent({
    paste(input$checkbox,
          input$okay_checkbox)
  },
  {
    if (is.null(input$checkbox) || input$checkbox == 0) {
      return()
    }
    show("okay_checkbox")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_SeI")
    hide("okay_Group")
    hide("okay_DaI")
    hide("okay_edit")
    hide("okay_LK")
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "checkbox")
    }
    checkbox <<- i
    sonstige <<- NULL
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block",
            tags$h1("Multiple choice", class = "modal-title")),
        div(class = "div inline-block", tags$img(src = paste(
          tr("multiple-img"), ".png", sep = ""
        ))),
        useShinyjs(),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste("question", " ", i, sep = ""),
          width = "150%",
          placeholder = "type here the question"
        ),
        #actionButton("add","answer ",icon = icon("plus")),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Select",
            "Text",
            "Range"
          ),
          selected = "Multiple"
        ),
        tags$hr(class = "div hr"),
        tags$br()
      )
      
    })
    
    output$Answer <- renderUI({
      changeQuestion(i)
    })
  })
  
  AnswerNum <- function(i, j) {
    answer <- list()
    tags_id1   <-
      paste("Question", i, j, "Answer", sep = "")
    tags_name1 <- paste(j, " ", "Answer", " ", sep = "")
    answer <-
      append(answer, list(div(
        style = "display:inline-flex",
        textInput(
          tags_id1,
          tags_name1,
          width = "50%",
          placeholder = tr("type here the answer")
        ),
        div(style = "height:10px;margin-top:25px", actionButton(
          paste("delete_answer", j, ""), "", icon = icon("remove")
        ),),
        div(style = "height:10px;margin-top:25px;margin-left:30px", actionButton(
          paste("addimage", j, sep = ""), "choose image", icon = icon("plus")
        ))
      )))
    return(answer)
  }
  
  answersum <<- list()
  NumQuestion <<-
    reactiveValues(wert = character(), imageNum = character())
  lapply(
    1:100,
    FUN = function(i) {
      observeEvent(input[[paste("add", i, "")]], {
        if (is.null(input[[paste("add", i, "")]])) {
          return()
        }
        if (input[[paste("add", i, "")]] > 0) {
          NumQuestion$wert <<- i
        }
        answernum <-
          input[[paste("add", NumQuestion$wert, "")]]
        
        NumQuestion$imageNum <<- answernum
        answersum <<-
          append(answersum, list(AnswerNum(NumQuestion$wert, answernum)))
      })
    }
  )
  
  observeEvent(input[[paste("addimage", NumQuestion$imageNum, sep = "")]], {
    if (is.null(input[[paste("addimage", NumQuestion$imageNum, sep = "")]])) {
      return(NULL)
    }
    sendSweetAlert(
      session = session,
      title = "imageproperty",
      text = tags$div(
        div(style = "margin-left:10px", fileInput(
          paste(
            "Question",
            NumQuestion$wert,
            "image",
            NumQuestion$imageNum,
            sep = ""
          ),
          "image upload"
        )),
        div(
          style = "display:inline-flex",
          textInput(
            paste(
              "Question",
              NumQuestion$wert,
              "image",
              NumQuestion$imageNum,
              "width",
              sep = ""
            ),
            "width"
          ),
          div(style = "height:10px;margin-top:25px;margin-left:20px", actionButton("origin", "", icon = icon("repeat"))),
          uiOutput("answerimage")
        ),
        div(style = "margin-left:10px", textInput(
          paste(
            "Question",
            NumQuestion$wert,
            "image",
            NumQuestion$imageNum,
            "height",
            sep = ""
          ),
          "height"
        )),
        div(
          style = "margin-left:10px",
          radioGroupButtons(
            paste(
              "Question",
              NumQuestion$wert,
              "image",
              NumQuestion$imageNum,
              "position",
              sep = ""
            ),
            "alignment",
            choiceNames = c(
              '<i class="left"></i>',
              '<i class="right"></i>',
              '<i class="top"></i>'
            ),
            choiceValues = c("left", "right", "top")
          ),
          textInput(
            paste(
              "Question",
              NumQuestion$wert,
              "image",
              NumQuestion$imageNum,
              "info",
              sep = ""
            ),
            "image info"
          )
        ),
      ),
      btn_labels = c("okay", "cancel"),
      btn_colors = c("#1D2938", "#1D2937"),
      closeOnClickOutside = T,
      showCloseButton = T
    )
  })
  
  size <-
    reactiveValues(sizeW = character(), sizeH = character())
  base64 <- reactive({
    inFile <-
      input[[paste("Question",
                   NumQuestion$wert,
                   "image",
                   NumQuestion$imageNum,
                   sep = "")]]
    if (!is.null(inFile)) {
      dataURI(file = inFile$datapath, mime = "image/png")
      require(png)
      file.copy(paste0(input[[paste("Question",
                                    NumQuestion$wert,
                                    "image",
                                    NumQuestion$imageNum,
                                    sep = "")]]$datapath), "www", overwrite = TRUE)
      image1 <-
        paste("www/", input[[paste("Question",
                                   NumQuestion$wert,
                                   "image",
                                   NumQuestion$imageNum,
                                   sep = "")]]$name, sep = "")
      img <- readPNG(image1)
      size$sizeW <- dim(img)[[1]]
      size$sizeH <- dim(img)[[2]]
    }
  })
  
  output$answerimage <- renderUI({
    if (!is.null(base64())) {
      if (input[[paste("Question",
                       NumQuestion$wert,
                       "image",
                       NumQuestion$imageNum,
                       "width",
                       sep = "")]] == "") {
        width <- size$sizeW
      }
      else{
        width <-
          input[[paste("Question",
                       NumQuestion$wert,
                       "image",
                       NumQuestion$imageNum,
                       "width",
                       sep = "")]]
      }
      if (input[[paste("Question",
                       NumQuestion$wert,
                       "image",
                       NumQuestion$imageNum,
                       "height",
                       sep = "")]] == "") {
        height <- size$sizeH
      }
      else{
        height <-
          input[[paste("Question",
                       NumQuestion$wert,
                       "image",
                       NumQuestion$imageNum,
                       "height",
                       sep = "")]]
      }
      tags$div(tags$img(
        input[[paste("Question",
                     NumQuestion$wert,
                     "image",
                     NumQuestion$imageNum,
                     sep = "")]]$name,
        width = width,
        height = height,
        align = paste(input[[paste("Question",
                                   NumQuestion$wert,
                                   "image",
                                   NumQuestion$imageNum,
                                   "position",
                                   sep = "")]], sep = "")
      ))
    }
  })
  
  observeEvent(input$origin, {
    if (is.null(input$origin)) {
      return(NULL)
    }
    updateTextInput(
      session,
      paste(
        "Question",
        NumQuestion$wert,
        "image",
        NumQuestion$imageNum,
        "width",
        sep = ""
      ),
      value = size$sizeW
    )
    updateTextInput(
      session,
      paste(
        "Question",
        NumQuestion$wert,
        "image",
        NumQuestion$imageNum,
        "height",
        sep = ""
      ),
      value = size$sizeH
    )
  })
  
  
  Sonstige <- function(i) {
    mu <- i
    sonstige <- list()
    num <- input[[paste("add", mu, "")]]
    Answer <- list()
    if (!is.null(input[[paste("sonstige", mu, sep = "")]])) {
      if (input[[paste("sonstige", mu, sep = "")]] == TRUE) {
        sonstige <-
          append(sonstige, list(textInput(
            paste("sonst", mu, sep = ""),
            paste0(num + 1, " Answer"),
            value = "Sonstiges"
          )))
      }
      else if (input[[paste("sonstige", mu, sep = "")]] == FALSE &&
               length(answersum) > num) {
        sonstige <- NULL
      }
    }
    
    Answer <- c(answersum, sonstige)
    return(Answer)
  }
  
  lapply(
    1:100,
    FUN = function(i) {
      output[[paste("answer", i, sep = "")]] <- renderUI({
        if (is.null(NumQuestion$wert)) {
          return(NULL)
        }
        input[[paste("add", i, "")]]
        input[[paste("delete_answer", lastBtn$minus, "")]]
        Sonstige(NumQuestion$wert)
      })
    }
  )
  
  multiple <- reactiveValues()
  observeEvent(input[[paste("delete_answer", lastBtn$minus, "")]], {
    multiple$answer <- append(multiple$answer, lastBtn$minus)
    sort(unlist(multiple$answer))
    multiple$list <- answersum
    answersum <<- multiple$list[-multiple$answer]
  })
  
  ###########################################Single Question##########################
  Rbn <<- NULL
  observeEvent({
    paste(input$RBn,
          input$okay_RBn)
  },
  {
    if (is.null(input$RBn) || input$RBn == 0) {
      return()
    }
    show("okay_RBn")
    hide("okay_Range")
    hide("okay_checkbox")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_SeI")
    hide("okay_DaI")
    hide("okay_edit")
    hide("okay_Group")
    hide("okay_LK")
    
    i <- get_submit_num() + 1
    
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "RBn")
    }
    
    sonstige <<- NULL
    Rbn <<- i
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block",
            tags$h1("Single question", class = "modal-title")),
        div(class = "div inline-block", tags$img(src = paste(
          tr("single-img"), ".png", sep = ""
        ))),
        useShinyjs(),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste("question", " ", i, sep = ""),
          width = "150%",
          placeholder = "type here the question"
        ),
        #actionButton("add","answer ",icon = icon("plus")),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range"
          ),
          selected = "Single"
        ),
        tags$hr(class = "div hr"),
        tags$br()
      )
      
    })
    
    output$Answer <- renderUI({
      changeQuestion(i)
    })
  })
  
  ###############################################Nummeric question##################################
  observeEvent({
    paste(input$numI,
          input$okay_numI)
  },
  {
    if (is.null(input$numI) || input$numI == 0) {
      return()
    }
    show("okay_numI")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_checkbox")
    hide("okay_TeI")
    hide("okay_SeI")
    hide("okay_DaI")
    hide("okay_edit")
    hide("okay_Group")
    hide("okay_LK")
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "NumInput")
    }
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block", tags$h1(tr(
          "numeric question"
        ), class = "modal-title")),
        div(class = "div inline-block", tags$img(src = paste(
          tr("numInput-img"), ".png", sep = ""
        ))),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste(tr("question"), " ", i, sep = ""),
          width = "150%",
          placeholder = tr("type here the question")
        ),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range"
          ),
          selected = "Nummer"
        )
      )
      
    })
    output$Answer <- renderUI({
      changeQuestion(i)
    })
  })
  
  ###########################################Textquestion##########################################3
  observeEvent({
    paste(input$TeI,
          input$okay_TeI)
  }, {
    if (is.null(input$TeI) || input$TeI == 0) {
      return()
    }
    show("okay_TeI")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_checkbox")
    hide("okay_SeI")
    hide("okay_DaI")
    hide("okay_edit")
    hide("okay_Group")
    hide("Fchange")
    hide("Fdelete")
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "TextInput")
    }
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block", tags$h1(tr(
          "Text question"
        ), class = "modal-title")),
        div(class = "div inline-block", tags$img(src = paste(
          tr("text-img"), ".png", sep = ""
        ))),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste(tr("question"), " ", i, sep = ""),
          width = "150%",
          placeholder = tr("type here the question")
        ),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range"
          ),
          selected = "Text"
        )
      )
    })
    
    output$Answer <- renderUI({
      changeQuestion(i)
    })
    
  })
  
  ##################################################Date question###############################
  observeEvent({
    paste(input$DaI, input$okay_DaI)
  }, {
    if (is.null(input$DaI) || input$DaI == 0) {
      return()
    }
    show("okay_DaI")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_SeI")
    hide("okay_checkbox")
    hide("okay_edit")
    hide("okay_LK")
    hide("okay_Group")
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "DateInput")
    }
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block", tags$h1(tr(
          "Date question"
        ), class = "modal-title")),
        div(class = "div inline-block", tags$img(src = paste(
          tr("Date-img"), ".png", sep = ""
        ))),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste(tr("question"), " ", i, sep = ""),
          width = "150%",
          placeholder = tr("type here the question")
        ),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range"
          ),
          selected = "Date"
        )
      )
      
    })
    
    output$Answer <- renderUI({
      tagList(
        fileInput(
          paste("myFile", i, sep = ""),
          tr("Insert picture"),
          multiple = TRUE,
          accept = c('image/png', 'image/jpeg'),
          width = "70%",
          placeholder = tr("No file selected")
        )
      )
    })
  })
  
  ###################################################SelectInput######################################################
  observeEvent({
    paste(input$SeI, input$okay_SeI)
  }, {
    if (is.null(input$SeI) || input$SeI == 0) {
      return()
    }
    show("okay_SeI")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_checkbox")
    hide("okay_DaI")
    hide("okay_edit")
    hide("okay_LK")
    hide("okay_Group")
    
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "SelectInput")
    }
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block", tags$h1(tr(
          "Select question"
        ), class = "modal-title")),
        div(class = "div inline-block", tags$img(src = paste(
          tr("select-img"), ".png", sep = ""
        ))),
        useShinyjs(),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste("question", " ", i, sep = ""),
          width = "150%",
          placeholder = "type here the question"
        ),
        #actionButton("add","answer ",icon = icon("plus")),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range"
          ),
          selected = "Select"
        ),
        tags$hr(class = "div hr"),
        tags$br()
      )
      
    })
    
    output$Answer <- renderUI({
      changeQuestion(i)
    })
    
  })
  
  LK_List <<- list()
  antwort <<- reactiveValues()
  
  ################################group question#####################################################
  observeEvent({
    paste(input$GR, input$okay_Group)
  }, {
    if (is.null(input$GR) || input$GR == 0) {
      return()
    }
    show("okay_Group")
    hide("okay_SeI")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_LK")
    hide("okay_checkbox")
    hide("okay_DaI")
    hide("okay_edit")
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "Group question")
    }
    GR <<- i
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block",
            tags$h1("Group question", class = "modal-title")),
        useShinyjs(),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste("question", " ", i, sep = ""),
          width = "150%",
          placeholder = "type here the question"
        ),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c("Multiple", "Single", "Range")
        ),
        tags$br(),
        tags$hr(class = "div hr"),
        uiOutput("QuestionAndAnswer"),
        tags$br(),
        fileInput(
          paste("myFile", GR, sep = ""),
          tr("Insert picture"),
          multiple = TRUE,
          accept = c('image/png', 'image/jpeg'),
          width = "70%"
        )
        
      )
    })
    
    # Add <- function(i){
    #   ADD <- list()
    #   ADD <- append(ADD,list(actionButton(paste("addquestion",i,""),"add question",icon = icon("plus"))))
    #   ADD <- append(ADD,list(uiOutput(paste("newfrage",i,""))))
    #
    #   return(ADD)
    # }
    
    output$QuestionAndAnswer <- renderUI({
      if (is.null(input[[paste("type", GR, sep = "")]])) {
        return(NULL)
      }
      if (input[[paste("type", GR, sep = "")]] == "Range") {
        tags$div(
          style = "display:inline-block;width:200px;",
          tags$h3("Question"),
          tags$hr(),
          actionButton(
            paste("addquestion", 2, ""),
            "add question",
            icon = icon("plus")
          ),
          uiOutput("newfrage2")
        )
      } else{
        tagList(
          tags$div(
            style = "display:inline-block;width:200px;",
            tags$h3("Question"),
            tags$hr(),
            actionButton(
              paste("addquestion", 2, ""),
              "add question",
              icon = icon("plus")
            ),
            uiOutput("newfrage2")
          ),
          tags$div(
            style = "display:inline-block;position:relativ;",
            tags$h3("Answer"),
            tags$hr(),
            actionButton("add", "add choice", icon = icon("plus")),
            uiOutput("inputs")
          )
        )
      }
    })
  })
  
  ids <<- NULL
  answerlist <<- NULL
  origin <-
    reactiveValues(answerid = vector(), questionid = vector())
  observeEvent(input$add, {
    i <- input$add
    ids <<- append(ids, i)
    origin$answerid <<- ids
    answer <- NULL
    # if(input[[paste("type",GR,sep = "")]] == "Range"){
    #   answerlist <<- list(
    #     textInput(paste("range1",GR,sep = ""),"range1",value = "",width = "50%"),
    #     textInput(paste("range2",GR,sep = ""),"range2",value = "",width = "50%"),
    #     numericInput(paste("SubAnswernum-",i,sep = ""),paste("please enter the range size"),value = 2,width = "20%",min = 2,max = 10)
    #   )
    # }
    
    tags_id1   <-
      paste("Question", GR, i, "Answer", sep = "")
    tags_id2   <- paste("choose", GR, i, sep = "")
    tags_name1 <- paste(i, " ", "Answer", " ", sep = "")
    answer <-
      append(answer, list(div(
        style = "display:inline-flex",
        textInput(
          tags_id1,
          tags_name1,
          width = "50%",
          placeholder = tr("type here the answer")
        ),
        div(style = "height:10px;margin-top:25px", actionButton(
          paste("delete_answer", i, ""), "", icon = icon("remove")
        ))
      )))
    
    answerlist <<- append(answerlist, list(answer))
    
    output$inputs <- renderUI({
      input$add
      if (is.null(answerlist)) {
        return()
      }
      answerlist
    })
  })
  
  questionGId <<- NULL
  questionlistSum <<- NULL
  observeEvent(input[[paste("addquestion", 2, "")]], {
    i <- input[[paste("addquestion", 2, "")]]
    questionGId <<- append(questionGId, i)
    origin$questionid <<- questionGId
    # print(i)
    
    question_id <- paste("Question_", GR, "_", i, sep = "")
    question_name <-
      paste("question ", GR, ".", i, sep = "")
    questionlist <- NULL
    
    
    if (input[[paste("type", GR, sep = "")]] == "Multiple") {
      questionlist <-
        append(questionlist, list(div(
          style = "display:inline-flex",
          textInput(
            question_id,
            question_name,
            width = "60%",
            placeholder = "type here the question"
          ),
          div(style = "height:10px;margin-top:25px", actionButton(
            paste("delete_question", i, ""), "", icon = icon("remove")
          ))
        )))
      
    } else if (input[[paste("type", GR, sep = "")]] == "Single") {
      questionlist <-
        append(questionlist, list(div(
          style = "display:inline-flex",
          textInput(
            question_id,
            question_name,
            width = "60%",
            placeholder = "type here the question"
          ),
          div(style = "height:10px;margin-top:25px", actionButton(
            paste("delete_question", i, ""), "", icon = icon("remove")
          ))
        )))
      
    }
    else if (input[[paste("type", GR, sep = "")]] == "Range") {
      questionlist <-
        append(questionlist, list(
          div(
            textInput(
              question_id,
              question_name,
              width = "70%",
              placeholder = "type here the question"
            ),
            textInput(
              paste("range1", i, sep = ""),
              "range1",
              value = "",
              width = "70%"
            ),
            textInput(
              paste("range2", i, sep = ""),
              "range2",
              value = "",
              width = "70%"
            ),
            numericInput(
              paste("SubAnswernum-", i, sep = ""),
              paste("please enter the range size"),
              value = 2,
              width = "50%",
              min = 2,
              max = 10
            ),
            tags$hr()
          )
        ))
      
    }
    questionlistSum <<-
      append(questionlistSum, list(questionlist))
    
    output$newfrage2 <- renderUI({
      input[[paste("addquestion", 2, "")]]
      if (is.null(questionlistSum)) {
        return()
      }
      else{
        questionlistSum
      }
    })
  })
  
  group <<- reactiveValues()
  observeEvent(input[[paste("delete_answer", lastBtn$minus, "")]], {
    group$answer <- append(group$answer, lastBtn$minus)
    sort(unlist(group$answer))
    group$list <- answerlist
    answerlist <<- group$list[-group$answer]
    ids <<- origin$answerid[-group$answer]
    
    output$inputs <- renderUI({
      answerlist
    })
  })
  
  observeEvent(input[[paste("delete_question", lastBtn$question, "")]], {
    #browser()
    group$question <-
      append(group$question, lastBtn$question)
    sort(unlist(group$question))
    questionlistSum <<- questionlistSum[-group$question]
    questionGId <<- origin$questionid[-group$question]
    
    output$newfrage2 <- renderUI({
      input[[paste("delete_question", lastBtn$question, "")]]
      questionlistSum
    })
  })
  
  answerADD <- function(j) {
    answerAdd <- NULL
    if (length(lisrG) > 0) {
      for (i in 1:length(questionlistSum)) {
        if (names(questionlistSum[i]) == paste("Question_", GR, "_", i, sep = "")) {
          answerAdd <- append(answerAdd, list(questionlistSum[[i]]))
        }
      }
    }
    
    return(answerAdd)
  }
  
  
  ##################################Linkage question###############################################
  observeEvent({
    paste(input$LK, input$okay_LK)
  }, {
    if (is.null(input$LK) || input$LK == 0) {
      return()
    }
    show("okay_LK")
    hide("okay_SeI")
    hide("okay_Range")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_checkbox")
    hide("okay_DaI")
    hide("okay_edit")
    hide("Fchange")
    hide("okay_Group")
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "linkage question")
    }
    LK <<- i
    
    output$Erstellen <- renderUI({
      tagList(
        div(
          class = "div inline-block",
          tags$h1("Linkage question", class = "modal-title")
        ),
        useShinyjs(),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste("question", " ", i, sep = ""),
          width = "150%",
          placeholder = "type here the question"
        ),
        #actionButton("add","answer ",icon = icon("plus")),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range",
            "Linkage"
          ),
          selected = "Linkage"
        ),
        #uiOutput("inputs"),
      )
    })
    
    Add <- function(i) {
      ADD <- list()
      ADD <-
        append(ADD, list(actionButton(
          paste("addquestion", 1, ""), "question ", icon = icon("plus")
        )))
      ADD <- append(ADD, list(uiOutput(paste(
        "newfrage", 1, ""
      ))))
      
      return(ADD)
    }
    
    output$Answer <- renderUI({
      tagList(
        Add(LK),
        tags$br(),
        fileInput(
          paste("myFile", LK, sep = ""),
          tr("Insert picture"),
          multiple = TRUE,
          accept = c('image/png', 'image/jpeg'),
          width = "70%"
        )
      )
    })
  })
  
  
  ## add question
  questionId <<- NULL
  observeEvent(input[[paste("addquestion", 1, "")]], {
    if (is.null(questionId)) {
      questionId <<- 1
    } else{
      questionId <<- c(questionId, max(questionId) + 1)
    }
    output[[paste("newfrage", 1, "")]] <- renderUI({
      div(lapply(1:length(questionId), function(i) {
        newQuestion(i)
      }),
      style = "display:inline-flex")
    })
  })
  
  newQuestion <- function(i) {
    question_id <- paste("Question_", LK, "_", i, sep = "")
    question_name <-
      paste("Question_", LK, "_", i, sep = "")
    tagList(
      div(
        useShinyjs(),
        textInput(
          question_id,
          question_name,
          width = "50%",
          placeholder = "type here the question"
        ),
        uiOutput(paste("newAnswer", i, "")),
        #selectInput(paste("type",i,sep = ""),"choose question type",width = "50%",choices = c("Multiple","Single","Date","Nummer","Text","select")),
        div(style = "height:30px", actionButton(
          paste("add", i, ""), "answer", icon = icon("plus")
        )),
        style = "display:inline-block;width:300px"
      )
    )
  }
  
  lastBtn <<-
    reactiveValues(
      add = character(),
      minus = character(),
      question = character(),
      deleteQ = character(),
      deleteA = character()
    )
  lapply(
    X = 1:100,
    FUN = function(i) {
      observeEvent(input[[paste("delete_answer", i, "")]], {
        if (input[[paste("delete_answer", i, "")]] > 0) {
          lastBtn$minus <<- i
        }
      })
      observeEvent(input[[paste("delete_question", i, "")]], {
        if (input[[paste("delete_question", i, "")]] > 0) {
          lastBtn$question <<- i
        }
      })
      observeEvent(input[[paste("add", i, "")]], {
        if (input[[paste("add", i, "")]] > 0) {
          lastBtn$add <<- i
        }
      })
    }
  )
  
  newAnswer <<- list()
  QList <<- list()
  observeEvent(input[[paste("add", lastBtn$add, "")]], {
    i <- lastBtn$add
    j <- input[[paste("add", lastBtn$add, "")]]
    answer <- NULL
    tags_id1   <-
      paste("Question_", LK, "_", i, "_", j, "Answer", sep = "")
    tags_name1 <- paste(j, " ", "Answer", " ", sep = "")
    answer <- append(answer, list(
      div(
        style = "display:inline-flex",
        checkboxInput(
          paste("question", i, "answer", j, sep = ""),
          "",
          value = FALSE,
          width = "10%"
        ),
        textInput(
          tags_id1,
          tags_name1,
          width = "70%",
          placeholder = tr("type here the answer")
        ),
        div(style = "height:20px;margin-top:25px", actionButton(
          paste("delete_answer", i, j, ""), "", icon = icon("remove")
        ))
      )
    ))
    
    names(answer) <- paste("question", lastBtn$add, "")
    newAnswer <<- append(newAnswer, answer)
    #AnswerSUM$new <<- append(AnswerSUM$new,list(question = list(name = input[[paste("Question",i,input[[paste("add",i,"")]],"Answer",sep = "")]],answer = answerADD(i))))
    
    # browser()
    lapply(
      2:lastBtn$add,
      FUN = function(i) {
        output[[paste("newAnswer", i, "")]] <- renderUI({
          input[[paste("add", i, "")]]
          answerADD(i)
        })
      }
    )
  })
  
  answerADD <- function(j) {
    answerAdd <<- NULL
    print(answerAdd)
    if (length(newAnswer) > 0) {
      for (i in 1:length(newAnswer)) {
        if (names(newAnswer[i]) == paste("question", j, "")) {
          answerAdd <<- append(answerAdd, list(newAnswer[[i]]))
        }
      }
    }
    
    return(answerAdd)
  }
  
  
  lapply(
    2:10,
    FUN = function(x) {
      lapply(
        1:10,
        FUN = function(y) {
          #browser()
          observeEvent(input[[paste("delete_answer", x, y, "")]], {
            if (input[[paste("delete_answer", x, y, "")]] > 0) {
              lastBtn$deleteQ <<- x
              lastBtn$deleteA <<- y
            }
          })
        }
      )
    }
  )
  
  
  wert <- reactiveValues(a = vector())
  observeEvent(input[[paste("delete_answer", lastBtn$deleteQ, lastBtn$deleteA, "")]], {
    AnswerSUM$Q <- append(AnswerSUM$Q, lastBtn$deleteQ)
    print(AnswerSUM$Q)
    if (length(AnswerSUM$Q) >= 2) {
      for (i in 2:length(AnswerSUM$Q)) {
        if (AnswerSUM$Q[i - 1] != AnswerSUM$Q[i]) {
          wert$a <- NULL
        }
      }
    }
    wert$a <- append(wert$a, lastBtn$deleteA)
    sort(unlist(wert$a))
    print(wert$a)
    AnswerSUM$new <- newAnswer
    
    lapply(
      2:lastBtn$add,
      FUN = function(i) {
        output[[paste("newAnswer", lastBtn$deleteQ, "")]] <- renderUI({
          input[[paste("delete_answer",
                       lastBtn$deleteQ,
                       lastBtn$deleteA,
                       "")]]
          newAnswer <<- newAnswer[-wert$a]
          QList <- answerADD(lastBtn$deleteQ)
          return(QList)
        })
      }
    )
  })
  
  
  # onclick("Question21Answer",updateTextInput(session,"Question21Answer",value = "1234"))
  
  
  ########################################Range Question############################################
  observeEvent({
    paste(input$FA,
          input$okay_Range)
  }, {
    if (is.null(input$FA) || input$FA == 0) {
      return()
    }
    show("okay_Range")
    hide("okay_checkbox")
    hide("okay_RBn")
    hide("okay_numI")
    hide("okay_TeI")
    hide("okay_SeI")
    hide("okay_DaI")
    hide("Fchange")
    hide("okay_edit")
    hide("okay_LK")
    hide("okay_Group")
    hide("Fdelete")
    
    
    i <- get_submit_num() + 1
    if (get_submit_num() > length(Dtype)) {
      Dtype <<- append(Dtype, "Range question")
    }
    
    output$Erstellen <- renderUI({
      tagList(
        div(class = "div inline-block",
            tags$h1("Range question", class = "modal-title")),
        useShinyjs(),
        tags$hr(class = "div hr"),
        textAreaInput(
          paste("Question_", i, sep = ""),
          paste("question", " ", i, sep = ""),
          width = "150%",
          placeholder = "type here the question"
        ),
        #actionButton("add","answer ",icon = icon("plus")),
        selectInput(
          paste("type", i, sep = ""),
          "choose question type",
          choices = c(
            "Multiple",
            "Single",
            "Date",
            "Nummer",
            "Text",
            "Select",
            "Range"
          ),
          selected = "Range"
        ),
        tags$br()
        
      )
    })
    
    
    output$Answer <- renderUI({
      changeQuestion(i)
    })
  })
  
  
  mark_Question <<- 1
  allQuestion <<- list()
  frage  <- reactiveValues()
  jlist <<- list()
  
  ###############################################Questionaire Questionmodel#######################################
  Fragemodel <- function(i) {
    imgs <- list()
    nimg <- list()
    inFile <- input[[paste("myFile", i, sep = "")]]
    imgfiles = nrow(inFile)
    numRange <- NULL
    
    jnum <- length(answersum)
    element <- NULL
    a <- NULL
    choices <- NULL
    answersum <<- NULL
    if (!is.null(jnum) || jnum == 0) {
      for (k in seq(1:jnum)) {
        a <-
          append(a, list(Answer = list(
            Answer_name = input[[paste("Question", i, k, "Answer", sep = "")]],
            Image = list(
              path = input[[paste("Question", i, "image", k, sep = "")]]$datapath,
              size = c(input[[paste("Question", i, "image", k, "width", sep = "")]], input[[paste("Question", i, "image", k, "height", sep = "")]]),
              position = input[[paste("Question", i, "image", k, "position", sep = "")]],
              info = input[[paste("Question", i, "image", k, "info", sep = "")]]
            )
          )))
        choices <-
          append(choices, input[[paste("Question", i, k, "Answer", sep = "")]])
      }
    }
    if (!is.null(input[[paste("sonstige", i, sep = "")]])) {
      if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
        a <- append(a, input[[paste("sonst", i, sep = "")]])
        choices <-
          append(choices, input[[paste("sonst", i, sep = "")]])
      }
    }
    
    if (!is.null(inFile)) {
      for (j in seq(1:imgfiles)) {
        temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
        imgs <- append(imgs, list(tags$div(
          tags$img(src = temp, class = "img-view")
        )))
        nimg <- append(nimg, temp)
      }
    }
    if (input[[paste("type", i, sep = "")]] == "Multiple") {
      element <-
        append(element, list(
          checkboxGroupInput(
            paste("Questionnbogen", i, sep = ""),
            input[[paste("Question_", i, sep = "")]],
            choices = choices,
            width = "70%"
          )
        ))
      list1 <-
        list(
          data_type = "numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = jnum,
          Answer_Str = a,
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "checkboxGroupInput"
        )
      jlist <<-
        append(jlist, list(Question_checkbox = list1))
    } else if (input[[paste("type", i, sep = "")]] == "Single") {
      if (!is.null(choices)) {
        element <-
          append(element, list(
            radioButtons(
              paste("Questionnbogen", i, sep = ""),
              input[[paste("Question_", i, sep = "")]],
              choices = choices,
              width = "70%"
            )
          ))
      } else{
        element <-
          append(element, list(radioButtons(
            paste("Questionnbogen", i, sep = ""),
            input[[paste("Question_", i, sep = "")]],
            choices = c("no choice"),
            width = "70%"
          )))
      }
      list1 <-
        list(
          data_type = "numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = jnum,
          Answer_Str = a,
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "radioButtons"
        )
      jlist <<- append(jlist, list(Question_RBn = list1))
    }
    else if (input[[paste("type", i, sep = "")]] == "Select") {
      element <-
        append(element, list(
          selectInput(
            paste("Questionnbogen", i, sep = ""),
            input[[paste("Question_", i, sep = "")]],
            choices = choices,
            width = "70%"
          )
        ))
      list1 <-
        list(
          data_type = "numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = jnum,
          Answer_Str = a,
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "selectInput"
        )
      jlist <<- append(jlist, list(Question_Select = list1))
    }
    else if (input[[paste("type", i, sep = "")]] == "Text") {
      element <-
        append(element, list(textInput(
          paste("Questionnbogen", i, sep = ""),
          input[[paste("Question_", i, sep = "")]],
          value = "",
          width = "70%"
        )))
      list1 <-
        list(
          data_type = "non_numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = NULL,
          Answer_Str = NULL,
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "textInput"
        )
      jlist <<- append(jlist, list(Question_text = list1))
    }
    else if (input[[paste("type", i, sep = "")]] == "Nummer") {
      element <-
        append(element, list(numericInput(
          paste("Questionnbogen", i, sep = ""),
          input[[paste("Question_", i, sep = "")]],
          value = "",
          width = "70%"
        )))
      list1 <-
        list(
          data_type = "non_numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = NULL,
          Answer_Str = list(input[[paste("range1_", i, sep = "")]], input[[paste("range2_", i, sep = "")]]),
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "numericInput"
        )
      jlist <<- append(jlist, list(Question_num = list1))
    }
    else if (input[[paste("type", i, sep = "")]] == "Date") {
      element <-
        append(element, list(dateInput(
          paste("Questionnbogen", i, sep = ""),
          input[[paste("Question_", i, sep = "")]],
          value = "",
          width = "70%"
        )))
      list1 <-
        list(
          data_type = "non_numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = NULL,
          Answer_Str = NULL,
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "checkboxGroupInput"
        )
      jlist <<- append(jlist, list(Question_date = list1))
    }
    else if (input[[paste("type", i, sep = "")]] == "Range") {
      a <- NULL
      jnum <- input[[paste("Answernum-", i, sep = "")]]
      a <- append(a, input[[paste("range1", i, sep = "")]])
      if (jnum > 2) {
        jnumN <- jnum - 2
        for (k in 1:jnumN) {
          a <- append(a, "")
        }
      }
      a <- append(a, input[[paste("range2", i, sep = "")]])
      jnum1 <- input[[paste("Answernum-", i, sep = "")]]
      if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
        a <- append(a, "Other")
        jnum1 <- jnum1 + 1
      }
      
      element <-
        append(element, list(radioButtons(
          paste("Questionnbogen", i, sep = ""),
          input[[paste("Question_", i, sep = "")]],
          choices = a,
          width = "70%"
        )))
      list1 <-
        list(
          data_type = "numeric",
          question_name = input[[paste("Question_", i, sep = "")]],
          Answer_nr = jnum1,
          Answer_Str = list(input[[paste("range1", i, sep = "")]], input[[paste("range2", i, sep = "")]]),
          Img_Nr = nrow(inFile),
          Img_paths = nimg,
          Shiny_Widgets_type = "radioButtons"
        )
      jlist <<- append(jlist, list(Question_range = list1))
    }
    return(element)
  }
  
  # a <<- 1
  ##############################################Questionaire generate#########################
  # get all the produced questions
  Fragenbogen <- reactive({
    input$okay_RBn
    input$okay_checkbox
    input$okay_TeI
    input$okay_Range
    input$okay_SeI
    input$okay_DaI
    input$okay_numI
    input$okay_LK
    input$okay_Group
    input$ok
    
    length_Question = length(Dtype)
    #browser()
    
    for (i in mark_Question:length_Question)
    {
      nimg <- list()
      jnum <- input[[paste("num", i, sep = "")]]
      inFile <- input[[paste("myFile", i, sep = "")]]
      imgfiles = nrow(inFile)
      numRange <- NULL
      
      if (Dtype[[i]] == "Range question") {
        imgs <- list()
        Range <- list()
        
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        for (k in length(answersum)) {
          if (!is.null(input[[paste("Question", i, "image", k, sep = "")]])) {
            imgs <- append(imgs, list(tags$div(
              tags$img(src = input[[paste("Question", i, "image", k, sep = "")]]$name, class = "img-view")
            )))
          }
        }
        
        Range <-
          append(Range, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Range <- append(Range, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", Fragemodel(i)),
          div(class = "div inline block", imgs)
        )))
        Range <-
          append(Range, list(
            tags$div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        
        allQuestion <<- append(allQuestion, list(Range))
      }
      else if (Dtype[[i]] == "Group question") {
        Group <- list()
        imgs <- list()
        questionlist <- NULL
        element <- NULL
        Widgetstype <- NULL
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        for (k in length(answersum)) {
          if (!is.null(input[[paste("Question", i, "image", k, sep = "")]])) {
            imgs <- append(imgs, list(tags$div(
              tags$img(src = input[[paste("Question", i, "image", k, sep = "")]]$name, class = "img-view")
            )))
          }
        }
        for (k in seq(1:length(questionGId))) {
          questionlist <-
            append(questionlist, list(input[[paste("Question_", i, "_", questionGId[k], sep = "")]]))
        }
        Answer <- NULL
        if (!is.null(questionGId)) {
          for (k in seq(1:length(questionGId))) {
            if (input[[paste("type", i, sep = "")]] == "Multiple") {
              # browser()
              answer <- NULL
              jnum <- length(ids)
              nameQ <-
                input[[paste("Question_", i, "_", questionGId[k], sep = "")]]
              Widgetstype <- "checkboxGroupInput"
              if (!is.null(jnum)) {
                for (t in seq(1:jnum)) {
                  answer <-
                    append(answer, input[[paste("Question", i, ids[t], "Answer", sep = "")]])
                }
              }
              Answer <- answer
              element <-
                append(element, list(
                  checkboxGroupInput(
                    paste("Questionnbogen", i, sep = ""),
                    nameQ,
                    choices = answer,
                    width = "70%"
                  )
                ))
            }
            else if (input[[paste("type", i, sep = "")]] == "Single") {
              answer <- NULL
              jnum <- length(ids)
              print(jnum)
              answerlist <<- list()
              nameQ <-
                input[[paste("Question_", i, "_", questionGId[k], sep = "")]]
              Widgetstype <- "radioButtons"
              if (!is.null(jnum)) {
                for (t in seq(1:jnum)) {
                  answer <-
                    append(answer, input[[paste("Question", i, ids[t], "Answer", sep = "")]])
                }
              }
              Answer <- answer
              element <-
                append(element, list(
                  radioButtons(
                    paste("Questionnbogen", i, sep = ""),
                    nameQ,
                    choices = answer,
                    width = "70%"
                  )
                ))
            }
            else if (input[[paste("type", i, sep = "")]] == "Range") {
              answer <- NULL
              jnum <-
                input[[paste("SubAnswernum-", k, sep = "")]]
              answer <-
                append(answer, input[[paste("range1", k, sep = "")]])
              nameQ <-
                input[[paste("Question_", i, "_", questionGId[k], sep = "")]]
              Widgetstype <- "Range-radioButtons"
              if (jnum > 2) {
                jnumN <- jnum - 2
                for (t in seq(1:jnumN)) {
                  answer <- append(answer, "")
                }
              }
              Answer <-
                list(input[[paste("range1", k, sep = "")]], input[[paste("range2", k, sep = "")]])
              answer <-
                append(answer, input[[paste("range2", k, sep = "")]])
              element <-
                append(element, list(
                  radioButtons(
                    paste("Questionnbogen", i, sep = ""),
                    nameQ,
                    choices = answer,
                    width = "70%"
                  )
                ))
            }
          }
        }
        questionlistSum <<- list()
        
        #browser()
        list0 <-
          list(
            data_type = "numeric",
            question_name = questionlist,
            Answer_nr = jnum,
            Answer_Str = Answer,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = Widgetstype
          )
        jlist <<-
          append(jlist, list(Question_Group = list(
            name = input[[paste("Question_", i, sep = "")]], Subquestion = list0
          )))
        Group <-
          append(Group, list(h4(
            paste("Question", i, " ", input[[paste("Question_", i, sep = "")]], sep = "")
          )))
        Group <- append(Group, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", element),
          div(class = "div inline block", imgs)
        )))
        Group <-
          append(Group, list(
            tags$div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion <<- append(allQuestion, list(Group))
      }
      else if (Dtype[[i]] == "linkage question") {
        imgs <- list()
        linkage <- list()
        
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        for (k in length(answersum)) {
          if (!is.null(input[[paste("Question", i, "image", k, sep = "")]])) {
            imgs <- append(imgs, list(tags$div(
              tags$img(src = input[[paste("Question", i, "image", k, sep = "")]]$name, class = "img-view")
            )))
          }
        }
        type <- input[[paste("type", i, sep = "")]]
        list1 <-
          list(
            data_type = "non-numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            relation_nr = NULL,
            Answer_Str = NULL,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = type
          )
        jlist <<-
          append(jlist, list(Question_linkage = list1))
        linkage <-
          append(linkage, list(h4(paste(
            "Question", i, sep = ""
          ))))
        
        for (k in seq(1:lastBtn$add)) {
          answer_num <- NULL
          frage <- NULL
          for (a in seq(1:input[[paste("add", lastBtn$add, "")]])) {
            answer_num <-
              append(answer_num, input[[paste("Question_", i, "_", k, "_", a, "Answer", sep = "")]])
          }
          list_sub = list(
            data_type = "linkage",
            question_name = input[[paste("Question_", i, "_", k, sep = "")]],
            relation_nr = NULL,
            Answer_Str = a,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = type
          )
          frage <-
            radioButtons(
              paste("Questionnbogen", i, "_", k, sep = ""),
              input[[paste("Question_", i, "_", k, sep = "")]],
              choices = a,
              width = "70%"
            )
          linkage <-
            append(linkage, list(list(
              tags$div(class = "mean-plot-row", div(
                class = "div box-question", frage, div(class = "div inline block", imgs)
              ))
            )))
        }
        
        allQuestion <<- append(allQuestion, list(linkage))
      }
      else if (Dtype[[i]] == "checkbox") {
        checkbox <- NULL
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        for (k in length(answersum)) {
          if (!is.null(input[[paste("Question", i, "image", k, sep = "")]])) {
            imgs <- append(imgs, list(tags$div(
              tags$img(src = input[[paste("Question", i, "image", k, sep = "")]]$name, class = "img-view")
            )))
          }
        }
        checkbox <-
          append(checkbox, list(h4(paste(
            "Question", i, sep = ""
          ))))
        checkbox <-
          append(checkbox, list(tags$div(
            class = "mean-plot-row",
            div(class = "div box-question", Fragemodel(i)),
            div(class = "div inline block", imgs)
          )))
        checkbox <-
          append(checkbox, list(
            tags$div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        
        
        allQuestion <<- append(allQuestion, list(checkbox))
        
      }
      else if (Dtype[[i]] == "RBn") {
        RBn <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        #browser()
        for (k in length(answersum)) {
          if (!is.null(input[[paste("Question", i, "image", k, sep = "")]])) {
            imgs <- append(imgs, list(tags$div(
              tags$img(src = input[[paste("Question", i, "image", k, sep = "")]]$name, class = "img-view")
            )))
          }
        }
        RBn <- append(RBn, list(h4(paste(
          "Question", i, sep = ""
        ))))
        RBn <- append(RBn, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", Fragemodel(i)),
          div(class = "div inline block", imgs)
        )))
        RBn <-
          append(RBn, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion <<- append(allQuestion, list(RBn))
      }
      else if (Dtype[[i]] == "SelectInput") {
        Select <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        for (k in length(answersum)) {
          if (!is.null(input[[paste("Question", i, "image", k, sep = "")]])) {
            imgs <- append(imgs, list(tags$div(
              tags$img(src = input[[paste("Question", i, "image", k, sep = "")]]$name, class = "img-view")
            )))
          }
        }
        Select <-
          append(Select, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Select <-
          append(Select, list(tags$div(
            class = "mean-plot-row",
            div(class = "div box-question", Fragemodel(i)),
            div(class = "div inline block", imgs)
          )))
        Select <-
          append(Select, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion <<- append(allQuestion, list(Select))
      }
      else if (Dtype[[i]] == "NumInput") {
        Num <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Num <- append(Num, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Num <- append(Num, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", Fragemodel(i)),
          div(class = "div inline block", imgs)
        )))
        Num <-
          append(Num, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion <<- append(allQuestion, list(Num))
      }
      else if (Dtype[[i]] == "TextInput") {
        Text <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Text <- append(Text, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Text <- append(Text, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", Fragemodel(i)),
          div(class = "div inline block", imgs)
        )))
        Text <-
          append(Text, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion <<- append(allQuestion, list(Text))
      }
      else if (Dtype[[i]] == "DateInput") {
        Date <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Date <- append(Date, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Date <- append(Date, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", Fragemodel(i)),
          div(class = "div inline block", imgs)
        )))
        Date <-
          append(Date, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion <<- append(allQuestion, list(Date))
      }
    }
    
    frage$before <- allQuestion
    frage$jlistbefore <- jlist
    
    mark_Question <<- length_Question + 1
    jqui_sortable(tags$ul(id = "lst", allQuestion, operation = "enable"))
    return(allQuestion)
  })
  
  ########################################sdaps####################################################
  sdaps_Pdf <- reactiveValues(pdf.path = NULL)
  
  
  #Save button - Extraction
  observeEvent(input$sdaps, {
    if (is.null(input$sdaps)) {
      return()
    }
    sendSweetAlert(
      session = session,
      title = NULL,
      text = tags$div(
        tags$h2("Please enter the questionaire title", style = "color:#1D2937"),
        tags$div(style = "margin-left:80px", textInput("Qname", "", value = "")),
        tags$div(
          style = "height:50px;",
          actionButton("infoName", "Next", width = "25%", style = "background-color:#1D2937;color:#8FE6F0;height:45px")
        )
      ),
      btn_labels = c("cancel"),
      btn_colors = c("#1D2937"),
      closeOnClickOutside = T,
      showCloseButton = T
    )
  })
  
  observeEvent(input$infoName, {
    sendSweetAlert(
      session = session,
      title = NULL,
      text = tags$div(
        tags$h2("Please enter the questionaire author", style = "color:#1D2937"),
        tags$div(style = "margin-left:80px", textInput("Author", "", value = "")),
        tags$div(
          style = "height:40px",
          actionButton("info_author",
                       "Okay",
                       width = "25%",
                       style = "background-color:#1D2937;color:#8FE6F0;height:45px")
        )
      ),
      btn_labels = c("cancel"),
      btn_colors = c("#1D2937"),
      closeOnClickOutside = T,
      showCloseButton = T
    )
  })
  
  observeEvent(input$info_author, {
    if (is.null(input$info_author)) {
      return()
    }
    
    closeSweetAlert()
    ###### PROGRESS BAR
    progress <- shiny::Progress$new()
    on.exit(progress$close())
    
    progress$set(message = 'Template for Sdaps Latex file generate', detail = NULL)
    
    test.data <-
      read_json(paste("C:\\Users\\asus\\Downloads\\", jsonname, sep = ""),
                simplifyVector = FALSE)
    Sys.sleep(0.2)
    progress$set(message = 'PDF generate', detail = "This may take a while ...")
    
    name <- input$Qname
    author <- input$Author
    Questions_Fabrik(test.data, name, author)
    tinytex::pdflatex("Template/project_example/Template_for_SDAPS.tex")
    Sys.sleep(0.2)
    
    file.move(
      paste0(
        getwd(),
        "/Template/project_example/Template_for_SDAPS.pdf"
      ),
      "www",
      overwrite = TRUE
    )
    
    progress$set(message = "PDF show", detail = NULL)
    ## view pdf
    output$pdfviewer <- renderUI({
      tags$iframe(style = "height:600px; width:100%", src = "/Template_for_SDAPS.pdf")
    })
  })
  
  
  
  #get the num of questions before alter
  Values <- reactiveValues()
  
  # get the num of questions
  get_okay <- reactive({
    if (is.null(input$new)) {
      Values$Alt <<- input$okay_RBn +
        input$okay_checkbox +
        input$okay_TeI +
        input$okay_Range +
        input$okay_SeI +
        input$okay_DaI +
        input$okay_numI +
        input$okay_edit +
        input$okay_LK +
        input$okay_Group
      
      return(Values$Alt)
    }
    else{
      Values$New <<- input$okay_RBn +
        input$okay_checkbox +
        input$okay_TeI +
        input$okay_Range +
        input$okay_SeI +
        input$okay_DaI +
        input$okay_numI +
        input$okay_edit +
        input$okay_LK +
        input$okay_Group +
        input$alt
      return(Values$New - Values$Alt)
    }
  })
  
  # Mark the last button pressed
  rv <-
    reactiveValues(lastBtn = 0,
                   lastEditBtn = 0,
                   edit = character())
  
  length_Question <<- length(Dtype)
  lapply(
    X = 1:100,
    FUN = function(i) {
      observeEvent(input[[paste0("delete", i)]], {
        if (input[[paste0("delete", i)]] > 0) {
          rv$lastBtn = i
        }
      })
      
      observeEvent(input[[paste0("edit", i)]], {
        if (input[[paste0("edit", i)]] > 0) {
          rv$lastEditBtn = i
        }
      })
    }
  )
  
  observeEvent({
    paste(
      input$okay_checkbox,
      input$okay_RBn,
      input$okay_Range,
      input$okay_numI,
      input$okay_TeI,
      input$okay_SeI,
      input$okay_DaI,
      input$alt,
      input$okay_LK,
      input$okay_Group
    )
  }, {
    if (is.null(input$okay_checkbox) ||
        is.null(input$okay_RBn) ||
        is.null(input$okay_Range) ||
        is.null(input$okay_numI) ||
        is.null(input$okay_TeI) ||
        is.null(input$okay_SeI) ||
        is.null(input$okay_DaI) ||
        is.null(input$alt) ||
        is.null(input$okay_LK ||
                is.null(input$okay_Group))) {
      return(NULL)
    }
    if (input$okay_checkbox > 0 ||
        input$okay_RBn > 0 ||
        input$okay_Range > 0 ||
        input$okay_numI > 0 ||
        input$okay_TeI > 0 ||
        input$okay_SeI > 0 ||
        input$okay_DaI > 0 ||
        input$alt > 0 ||
        input$LK > 0 || input$okay_Group > 0) {
      rv$edit = "FALSE"
    }
  })
  
  observeEvent(input$okay_edit, {
    if (is.null(input$okay_edit)) {
      return(NULL)
    }
    if (input$okay_edit > 0) {
      rv$edit = "TRUE"
    }
  })
  
  
  ####################################################edit question#########################################
  
  lapply(
    X = 1:100,
    FUN = function(i) {
      observeEvent(input[[paste0("edit", i)]], {
        if (input[[paste0("edit", i)]] == 0) {
          return()
        }
        show("okay_edit")
        hide("okay_RBn")
        hide("okay_Range")
        hide("okay_checkbox")
        hide("okay_numI")
        hide("okay_TeI")
        hide("okay_SeI")
        hide("okay_DaI")
        hide("okay_LK")
        inFile1 <- input$new
        i <- rv$lastEditBtn
        
        if (is.null(inFile1)) {
          if (Dtype[[i]] == "checkbox") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(
                  tr("multiple choice"), class = "modal-title"
                )),
                div(class = "div inline-block", tags$img(src = "multiple.png")),
                tags$hr(class = "div hr"),
                
                tags$head(tags$style(HTML(
                  paste("#num", i, "{height: 40px}", sep = '')
                ))),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  height = "50px",
                  placeholder = tr("type here the question")
                ),
                numericInput(
                  paste("num", i, sep = ""),
                  tr("Number of Answer"),
                  value = input[[paste("num", i, sep = "")]],
                  width = "20%"
                ),
                checkboxInput(
                  paste("sonstige", i, sep = ""),
                  tr("Sonstige Choice"),
                  value = FALSE
                )
              )
            })
          }
          # else if(Dtype[[i]] == "linkage question"){
          #   output$Erstellen <- renderUI({
          #     tagList(div(class="div inline-block",tags$h1("Linkage question",class = "modal-title")),
          #             # div(class="div inline-block",tags$img(src = paste(tr("select-img"),".png",sep = ""))),
          #             tags$hr(class = "div hr"),
          #             textAreaInput(paste("Question_",i,sep = ""),paste(tr("question")," ",i,sep = ""),width = "150%",placeholder = tr("type here the question")),
          #             fileInput(paste("myFile",i,sep = ""), tr("Insert picture"), multiple = TRUE, accept = c('image/png', 'image/jpeg'),width = "70%",placeholder = tr("No file selected"))
          #     )
          #   })
          # }
          else if (Dtype[[i]] == "Range question") {
            output$Erstellen <- renderUI({
              tagList(
                div(
                  class = "div inline-block",
                  tags$h1("Range question", class = "modal-title")
                ),
                useShinyjs(),
                tags$hr(class = "div hr"),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste("question", " ", i, sep = ""),
                  value = input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  placeholder = "type here the question"
                ),
                #actionButton("add","answer ",icon = icon("plus")),
                selectInput(
                  paste("type", i, sep = ""),
                  "choose question type",
                  choices = c(
                    "Multiple",
                    "Single",
                    "Date",
                    "Nummer",
                    "Text",
                    "select",
                    "Range"
                  ),
                  selected = "Range"
                ),
                textInput(
                  paste("range1", i, sep = ""),
                  "range1",
                  value = input[[paste("range1", i, sep = "")]],
                  width = "50%"
                ),
                textInput(
                  paste("range2", i, sep = ""),
                  "range2",
                  value = input[[paste("range2", i, sep = "")]],
                  width = "50%"
                ),
                numericInput(
                  paste("Answernum-", i, sep = ""),
                  paste("please enter the range size"),
                  value = input[[paste("Answernum-", i, sep = "")]],
                  width = "20%",
                  min = 2,
                  max = 10
                ),
                checkboxInput(
                  paste("sonstige", i, sep = ""),
                  tr("Sonstige Choice"),
                  value = FALSE
                ),
                tags$br()
                
              )
            })
          }
          else if (Dtype[[i]] == "RBn") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h4(tr(
                  "single choice"
                ), class = "modal-title")),
                div(class = "div inline-block", tags$img(src = "singe.png")),
                tags$hr(class = "div hr"),
                
                tags$head(tags$style(HTML(
                  paste("#num", i, "{height: 40px}", sep = '')
                ))),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  height = "50px",
                  placeholder = tr("type here the question")
                ),
                numericInput(
                  paste("num", i, sep = ""),
                  tr("Number of Answer"),
                  value = input[[paste("num", i, sep = "")]],
                  width = "20%"
                ),
                checkboxInput(
                  paste("sonstige", i, sep = ""),
                  tr("Sonstige Choice"),
                  value = FALSE
                )
              )
            })
          }
          else if (Dtype[[i]] == "SelectInput") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(
                  tr("Select question"), class = "modal-title"
                )),
                div(class = "div inline-block", tags$img(src = "select.png")),
                tags$hr(class = "div hr"),
                
                tags$head(tags$style(HTML(
                  paste("#num", i, "{height: 40px}", sep = '')
                ))),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  height = "50px",
                  placeholder = tr("type here the question")
                ),
                numericInput(
                  paste("num", i, sep = ""),
                  tr("Number of Answer"),
                  value = input[[paste("num", i, sep = "")]],
                  width = "20%"
                )
              )
              
            })
          }
          else if (Dtype[[i]] == "NumInput") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(
                  tr("numeric question"), class = "modal-title"
                )),
                div(class = "div inline-block", tags$img(src = "numInput.png")),
                tags$hr(class = "div hr"),
                
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  placeholder = tr("type here the question")
                ),
                div(
                  style = "display:inline-block;100px",
                  numericInput(
                    paste("range1_", i, sep = ""),
                    tr("from"),
                    value = "",
                    width = "30%"
                  )
                ),
                div(
                  class = "div inline-block",
                  numericInput(
                    paste("range2_", i, sep = ""),
                    tr("to"),
                    value = "",
                    width = "30%"
                  )
                )
              )
              
            })
          }
          else if (Dtype[[i]] == "TextInput") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(tr(
                  "Text question"
                ), class = "modal-title")),
                div(class = "div inline-block", tags$img(src = "text.png")),
                tags$hr(class = "div hr"),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  placeholder = tr("type here the question")
                )
              )
            })
          }
          else if (Dtype[[i]] == "DateInput") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(tr(
                  "Date question"
                ), class = "modal-title")),
                div(class = "div inline-block", tags$img(src = "Date.png")),
                tags$hr(class = "div hr"),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = input[[paste("Question_", i, sep = "")]],
                  width = "150%",
                  placeholder = tr("type here the question")
                )
              )
              
            })
          }
          
          Enum <- reactiveValues()
          
          value1 <- list()
          jnum <- input[[paste("num", i, sep = "")]]
          Enum$a <- jnum
          if (!is.null(jnum)) {
            for (k in 1:jnum) {
              value1 <-
                append(value1, input[[paste("Question", i, k, "Answer", sep = "")]])
            }
            if (input[[paste("sonstige", i, sep = "")]] == TRUE &&
                !is.null(input[[paste("sonstige", i, sep = "")]])) {
              value1 <- append(value1, input[[paste("sonst", i, sep = "")]])
            }
          }
          
          #####################################################################Edit question########################################################################################
          AnswerNum <- function() {
            num_id <- paste("num", i, sep = "")
            Enum$b <- input[[num_id]]
            if (is.null(input[[num_id]]) ||
                input[[num_id]] == 0) {
              return()
            }
            a <- as.numeric(input[[num_id]])
            answer <- list()
            if (Enum$a >= Enum$b &&
                Dtype[[i]] != "NumInput" &&
                Dtype[[i]] != "TextInput" &&
                Dtype[[i]] != "DateInput") {
              for (j in 1:Enum$a) {
                tags_id   <- paste("Question", i, j, "Answer", sep = "")
                tags_name <-
                  paste(j, " ", tr("Answer"), " ", sep = "")
                
                answer <-
                  append(answer, list(
                    textAreaInput(
                      tags_id,
                      tags_name,
                      value = value1[[j]],
                      width = "150%",
                      placeholder = tr("type here the answer")
                    )
                  ))
              }
            }
            else if (Enum$a < Enum$b) {
              for (j in 1:Enum$a) {
                tags_id   <- paste("Question", i, j, "Answer", sep = "")
                tags_name <-
                  paste(j, " ", tr("Answer"), " ", sep = "")
                
                answer <-
                  append(answer, list(
                    textAreaInput(
                      tags_id,
                      tags_name,
                      value = value1[[j]],
                      width = "150%",
                      placeholder = tr("type here the answer")
                    )
                  ))
              }
              begin <- Enum$a + 1
              for (k in begin:Enum$b) {
                tags_id   <- paste("Question", i, k, "Answer", sep = "")
                tags_name <- paste(k, " Answer ", sep = "")
                
                answer <-
                  append(answer, list(
                    textAreaInput(
                      tags_id,
                      tags_name,
                      width = "150%",
                      placeholder = tr("type here the answer")
                    )
                  ))
              }
            }
            if (input[[paste("sonstige", i, sep = "")]] == TRUE &&
                !is.null(input[[paste("sonstige", i, sep = "")]])) {
              answer <-
                append(answer, list(textInput(
                  paste("sonst", i, sep = ""),
                  paste(input[[paste(tr("num"), i, sep = "")]] + 1, " Answer"),
                  value = "Sonstiges"
                )))
            }
            return(answer)
          }
          
          output$Answer <- renderUI({
            tagList(
              AnswerNum(),
              fileInput(
                paste("myFile", i, sep = ""),
                tr("Insert picture"),
                multiple = TRUE,
                accept = c('image/png', 'image/jpeg'),
                width = "70%",
                placeholder = tr("No file selected")
              )
            )
          })
        }
        else{
          df3 <- read_json(inFile1$datapath)
          if (names(df3[i]) == "Question_checkbox") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(
                  tr("multiple choice"), class = "modal-title"
                )),
                div(class = "div inline-block", tags$img(src = "multiple.png")),
                tags$hr(class = "div hr"),
                
                tags$head(tags$style(HTML(
                  paste("#num", i, "{height: 40px}", sep = '')
                ))),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  height = "50px",
                  placeholder = tr("type here the question")
                ),
                numericInput(
                  paste("num", i, sep = ""),
                  tr("Number of Answer"),
                  value = df3[[i]]$Answer_nr,
                  width = "20%"
                ),
                checkboxInput(
                  paste("sonstige", i, sep = ""),
                  tr("Sonstige Choice"),
                  value = FALSE
                )
              )
              
            })
          }
          else if (names(df3[i]) == "linkage question") {
            a <- NULL
            linkage <- list()
            imgs <- list()
            for (k in seq(1:length(ids))) {
              a <- append(a, input[[paste("Question", i, k, "Answer", sep = "")]])
            }
            if (!is.null(inFile)) {
              for (j in seq(1:imgfiles)) {
                temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
                imgs <- append(imgs, list(tags$div(
                  tags$img(src = temp, class = "img-view")
                )))
                nimg <- append(nimg, temp)
              }
            }
            type <- input[[paste("type", i, sep = "")]]
            frage <- NULL
            list1 <-
              list(
                data_type = "linkage",
                question_name = input[[paste("Question_", i, sep = "")]],
                Answer_nr = jnum,
                Answer_Str = a,
                Img_Nr = nrow(inFile),
                Img_paths = nimg,
                Shiny_Widgets_type = type
              )
            jlist <<-
              append(jlist, list(Question_checkbox = list1))
            if (type == "Multiple") {
              frage <-
                checkboxGroupInput(
                  paste("Questionnbogen", i, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  choices = a,
                  width = "70%"
                )
            }
            else if (type == "Single") {
              frage <-
                radioButtons(
                  paste("Questionnbogen", i, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  choices = a,
                  width = "70%"
                )
            }
            else if (type == "Date") {
              frage <-
                dateInput(paste("Questionnbogen", i, sep = ""),
                          input[[paste("Question_", i, sep = "")]],
                          width = "70%")
            }
            else if (type == "Nummer") {
              frage <-
                numericInput(paste("Questionnbogen", i, sep = ""),
                             input[[paste("Question_", i, sep = "")]],
                             width = "70%")
            }
            else if (type == "Text") {
              frage <-
                textInput(paste("Questionnbogen", i, sep = ""),
                          input[[paste("Question_", i, sep = "")]],
                          width = "70%")
            }
            else if (type == "select") {
              frage <-
                selectInput(
                  paste("Questionnbogen", i, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  choices = a,
                  width = "70%"
                )
            }
            
            linkage <-
              append(linkage, list(h4(paste(
                "Question", i, sep = ""
              ))))
            linkage <-
              append(linkage, list(tags$div(
                class = "mean-plot-row",
                div(class = "div box-question",
                    frage, div(class = "div inline block", imgs))
              )))
            linkage <-
              append(linkage, list(
                tags$div(
                  class = "div box-btn",
                  actionButton(
                    paste0("delete", i),
                    tr("Delete"),
                    icon = icon("trash"),
                    class = "btn-type btn-delete"
                  ),
                  actionButton(
                    paste0("edit", i),
                    tr("Edit"),
                    icon = icon("pencil"),
                    class = "btn-type btn-edit"
                  )
                )
              ))
            
            
            allQuestion <<-
              append(allQuestion, list(linkage))
          }
          else if (names(df3[i]) == "Question_RBn") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(tr(
                  "single choice"
                ), class = "modal-title")),
                div(class = "div inline-block", tags$img(src = "singe.png")),
                tags$hr(class = "div hr"),
                
                tags$head(tags$style(HTML(
                  paste("#num", i, "{height: 40px}", sep = '')
                ))),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  height = "50px",
                  placeholder = tr("type here the question")
                ),
                numericInput(
                  paste("num", i, sep = ""),
                  tr("Number of Answer"),
                  value = df3[[i]]$Answer_nr,
                  width = "20%"
                ),
                checkboxInput(
                  paste("sonstige", i, sep = ""),
                  tr("Sonstige Choice"),
                  value = FALSE
                )
              )
              
            })
          }
          else if (names(df3[i]) == "Question_Range") {
            output$Erstellen <- renderUI({
              tagList(
                div(
                  class = "div inline-block",
                  tags$h1("Range question", class = "modal-title")
                ),
                useShinyjs(),
                tags$hr(class = "div hr"),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste("question", " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  placeholder = "type here the question"
                ),
                #actionButton("add","answer ",icon = icon("plus")),
                selectInput(
                  paste("type", i, sep = ""),
                  "choose question type",
                  choices = c(
                    "Multiple",
                    "Single",
                    "Date",
                    "Nummer",
                    "Text",
                    "select",
                    "Range"
                  ),
                  selected = "Range"
                ),
                textInput(
                  paste("range1", i, sep = ""),
                  "range1",
                  value = df3[[i]]$Answer_Str[[1]],
                  width = "50%"
                ),
                textInput(
                  paste("range2", i, sep = ""),
                  "range2",
                  value = df3[[i]]$Answer_Str[[2]],
                  width = "50%"
                ),
                numericInput(
                  paste("Answernum-", i, sep = ""),
                  paste("please enter the range size"),
                  value = 2,
                  width = "20%",
                  min = 2,
                  max = 10
                ),
                checkboxInput(
                  paste("sonstige", i, sep = ""),
                  tr("Sonstige Choice"),
                  value = FALSE
                ),
                tags$br()
                
              )
            })
          }
          else if (names(df3[i]) == "Question_Se") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(
                  tr("Select question"), class = "modal-title"
                )),
                div(class = "div inline-block", tags$img(src = "select.png")),
                tags$hr(class = "div hr"),
                
                tags$head(tags$style(HTML(
                  paste("#num", i, "{height: 40px}", sep = '')
                ))),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  height = "50px",
                  placeholder = tr("type here the question")
                ),
                numericInput(
                  paste("num", i, sep = ""),
                  tr("Number of Answer"),
                  value = df3[[i]]$Answer_nr,
                  width = "20%"
                )
              )
              
            })
          }
          else if (names(df3[i]) == "Question_num") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(
                  tr("numeric question"), class = "modal-title"
                )),
                div(class = "div inline-block", tags$img(src = "numInput.png")),
                tags$hr(class = "div hr"),
                
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  placeholder = tr("type here the question")
                ),
                div(
                  style = "display:inline-block;100px",
                  numericInput(
                    paste("range1_", i, sep = ""),
                    tr("from"),
                    value = "",
                    width = "30%"
                  )
                ),
                div(
                  class = "div inline-block",
                  numericInput(
                    paste("range2_", i, sep = ""),
                    tr("to"),
                    value = "",
                    width = "30%"
                  )
                )
              )
              
            })
          }
          else if (names(df3[i]) == "Question_date") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(tr(
                  "Date question"
                ), class = "modal-title")),
                div(class = "div inline-block", tags$img(src = "Date.png")),
                tags$hr(class = "div hr"),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  placeholder = tr("type here the question")
                )
              )
              
            })
          }
          else if (names(df3[i]) == "Question_text") {
            output$Erstellen <- renderUI({
              tagList(
                div(class = "div inline-block", tags$h1(tr(
                  "Text question"
                ), class = "modal-title")),
                div(class = "div inline-block", tags$img(src = "text.png")),
                tags$hr(class = "div hr"),
                textAreaInput(
                  paste("Question_", i, sep = ""),
                  paste(tr("question"), " ", i, sep = ""),
                  value = df3[[i]]$question_name,
                  width = "150%",
                  placeholder = tr("type here the question")
                )
              )
            })
          }
          
          Enum1 <- reactiveValues()
          Enum1$a <- df3[[i]]$Answer_nr
          
          AnswerNum <- function() {
            num_id <- paste("num", i, sep = "")
            if (is.null(input[[num_id]]) ||
                input[[num_id]] == 0) {
              return()
            }
            a <- as.numeric(input[[num_id]])
            answer <- list()
            Enum1$b <- input[[num_id]]
            
            if (Enum1$a >= Enum1$b) {
              for (j in 1:Enum1$b) {
                tags_id   <- paste("Question", i, j, "Answer", sep = "")
                tags_name <-
                  paste(j, " ", tr("Answer"), " ", sep = "")
                
                answer <-
                  append(answer, list(
                    textAreaInput(
                      tags_id,
                      tags_name,
                      value = df3[[i]]$Answer_Str[[j]],
                      width = "150%",
                      placeholder = tr("type here the answer")
                    )
                  ))
              }
            }
            else{
              for (j in 1:Enum1$a) {
                tags_id   <- paste("Question", i, j, "Answer", sep = "")
                tags_name <-
                  paste(j, " ", tr("Answer"), " ", sep = "")
                
                answer <-
                  append(answer, list(
                    textAreaInput(
                      tags_id,
                      tags_name,
                      value = df3[[i]]$Answer_Str[[j]],
                      width = "150%",
                      placeholder = tr("type here the answer")
                    )
                  ))
              }
              begin <- Enum1$a + 1
              for (k in begin:Enum1$b) {
                tags_id   <- paste("Question", i, k, "Answer", sep = "")
                tags_name <- paste(k, " Answer ", sep = "")
                
                answer <-
                  append(answer, list(
                    textAreaInput(
                      tags_id,
                      tags_name,
                      width = "150%",
                      placeholder = tr("type here the answer")
                    )
                  ))
              }
            }
            if (input[[paste("sonstige", i, sep = "")]] == TRUE &&
                !is.null(input[[paste("sonstige", i, sep = "")]])) {
              answer <-
                append(answer, list(textInput(
                  paste("sonst", i, sep = ""),
                  paste(input[[paste(tr("num"), i, sep = "")]] + 1, " Answer"),
                  value = "Sonstiges"
                )))
            }
            return(answer)
          }
          
          output$Answer <- renderUI({
            tagList(
              AnswerNum(),
              fileInput(
                paste("myFile", i, sep = ""),
                tr("Insert picture"),
                multiple = TRUE,
                accept = c('image/png', 'image/jpeg'),
                width = "70%",
                placeholder = tr("No file selected")
              )
            )
          })
        }
      })
    }
  )
  
  position <<- NULL
  # edit question button (noch nicht fertig)
  Edit <- reactive({
    input$okay_edit
    inFile1 <- input$new
    
    if (rv$lastBtn < rv$lastEditBtn && rv$lastBtn != 0) {
      position <<- rv$lastEditBtn - 1
    }
    else{
      position <<- rv$lastEditBtn
    }
    
    i <- rv$lastEditBtn
    index <- position
    nimg <- list()
    inFile <- input[[paste("myFile", i, sep = "")]]
    if (is.null(inFile1)) {
      return
    }
    imgfiles = nrow(inFile)
    rnum <- input[[paste("num", i, sep = "")]]
    
    if (is.null(input$new)) {
      if (Dtype[[i]] == "checkbox") {
        a <- NULL
        checkbox <- list()
        imgs <- list()
        for (k in seq(1:rnum)) {
          a <- append(a, input[[paste("Question", i, k, "Answer", sep = "")]])
        }
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, input[[paste("sonst", i, sep = "")]])
          rnum <- rnum + 1
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list1 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = rnum,
            Answer_Str = a,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "checkboxGroupInput"
          )
        jlist[[index]] <<- list1
        checkbox <-
          append(checkbox, list(h4(paste(
            "Question", i, sep = ""
          ))))
        checkbox <-
          append(checkbox, list(tags$div(
            class = "mean-plot-row",
            div(class = "div box-question",
                checkboxGroupInput(
                  paste("Questionnbogen", i, sep = ""), input[[paste("Question_", i, sep = "")]], choices = a
                )),
            div(class = "div inline block", imgs)
          )))
        checkbox <-
          append(checkbox, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion[[index]] <<- checkbox
      }
      else if (Dtype[[i]] == "Range question") {
        imgs <- list()
        Range <- list()
        a <- NULL
        jnum <- input[[paste("Answernum-", i, sep = "")]]
        a <-
          append(a, input[[paste("range1", i, sep = "")]])
        if (jnum > 2) {
          jnumN <- jnum - 2
          for (k in 1:jnumN) {
            a <- append(a, "")
          }
        }
        a <-
          append(a, input[[paste("range2", i, sep = "")]])
        
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, "Other")
          jnum <- jnum + 1
        }
        
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        list0 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = jnum,
            Answer_Str = a,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "radioButton"
          )
        jlist <<-
          append(jlist, list(Question_Range = list0))
        
        Range <-
          append(Range, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Range <- append(Range, list(tags$div(
          class = "mean-plot-row",
          div(
            class = "div box-question",
            radioButtons(
              paste("Questionnbogen", i, sep = ""),
              input[[paste("Question_", i, sep = "")]],
              choices = a,
              width = "70%"
            )
          ),
          div(class = "div inline block", imgs)
        )))
        Range <-
          append(Range, list(
            tags$div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        
        allQuestion[[index]] <<- Range
      }
      # else if(Dtype[[i]] == "linkage question"){
      #   a <- NULL
      #   linkage <- list()
      #   imgs <- list()
      #   for(k in seq(1:length(ids))){
      #     a <- append(a,input[[paste("Question",i,k,"Answer",sep = "")]])
      #   }
      #   if(!is.null(inFile)){
      #     for(j in seq(1:imgfiles)){
      #       temp <- dataURI(file = inFile[[j,'datapath']], mime = "image/png")
      #       imgs <- append(imgs,list(tags$div(
      #         tags$img(src = temp, class = "img-view"))))
      #       nimg <- append(nimg,temp)
      #     }
      #   }
      #   type <- input[[paste("type",i,sep = "")]]
      #   frage <- NULL
      #   list1 <- list(data_type = "linkage",question_name = input[[paste("Question_",i,sep = "")]],Answer_nr = jnum, Answer_Str = a,Img_Nr = nrow(inFile),Img_paths = nimg,Shiny_Widgets_type = type)
      #   jlist[[index]] <<- append(jlist,list(Question_checkbox = list1))
      #   if(type == "Multiple"){
      #     frage <- checkboxGroupInput(paste("Questionnbogen",i,sep = ""),input[[paste("Question_",i,sep = "")]],choices = a,width = "70%")}
      #   else if(type == "Single"){
      #     frage <- radioButtons(paste("Questionnbogen",i,sep = ""),input[[paste("Question_",i,sep = "")]],choices = a,width = "70%")}
      #   else if(type == "Date"){
      #     frage <- dateInput(paste("Questionnbogen",i,sep = ""),input[[paste("Question_",i,sep = "")]],width = "70%")}
      #   else if(type == "Nummer"){
      #     frage <- numericInput(paste("Questionnbogen",i,sep = ""),input[[paste("Question_",i,sep = "")]],width = "70%")}
      #   else if(type == "Text"){
      #     frage <- textInput(paste("Questionnbogen",i,sep = ""),input[[paste("Question_",i,sep = "")]],width = "70%")}
      #   else if(type == "select"){
      #     frage <- selectInput(paste("Questionnbogen",i,sep = ""),input[[paste("Question_",i,sep = "")]],choices = a,width = "70%")}
      #
      #   linkage <- append(linkage,list(h4(paste("Question",i,sep = ""))))
      #   linkage <- append(linkage,list(tags$div(class = "mean-plot-row",
      #                                           div(class = "div box-question",
      #                                               frage,div(class = "div inline block",imgs)))))
      #   linkage <- append(linkage,list(tags$div(class = "div box-btn",actionButton(paste0("delete",i),tr("Delete"),icon = icon("trash"),class = "btn-type btn-delete"),
      #                                           actionButton(paste0("edit",i),tr("Edit"),icon = icon("pencil"),class = "btn-type btn-edit"))))
      #
      #
      #   allQuestion[[index]] <<- append(allQuestion,list(linkage))
      # }
      else if (Dtype[[i]] == "RBn") {
        e <- NULL
        RBn <- list()
        imgs <- list()
        for (k in seq(1:rnum)) {
          e <- append(e, input[[paste("Question", i, k, "Answer", sep = "")]])
        }
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, input[[paste("sonst", i, sep = "")]])
          rnum <- rnum + 1
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list2 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = rnum,
            Answer_Str = e,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "radioButtons"
          )
        jlist[[index]] <<- list2
        RBn <- append(RBn, list(h4(paste(
          "Question", i, sep = ""
        ))))
        RBn <- append(RBn, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", radioButtons(
            paste0("Questionnbogen", i), input[[paste("Question_", i, sep = "")]], choices = e
          )),
          div(class = "div inline block", imgs)
        )))
        RBn <-
          append(RBn, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion[[index]] <<- RBn
      }
      else if (Dtype[[i]] == "SelectInput") {
        h <- NULL
        Select <- list()
        imgs <- list()
        for (k in seq(1:rnum)) {
          h <- append(h, input[[paste("Question", i, k, "Answer", sep = "")]])
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list3 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = rnum,
            Answer_Str = h,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "selectInput"
          )
        jlist[[index]] <<- list3
        Select <-
          append(Select, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Select <-
          append(Select, list(tags$div(
            class = "mean-plot-row",
            div(class = "div box-question", selectInput(
              paste("selectInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], choices = h
            )),
            div(class = "div inline block", imgs)
          )))
        Select <-
          append(Select, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion[[index]] <<- Select
      }
      else if (Dtype[[i]] == "NumInput") {
        Num <- list()
        imgs <- list()
        numRange <- NULL
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        numRange <-
          append(numRange, input[[paste("range1_", i, sep = "")]])
        numRange <-
          append(numRange, input[[paste("range2_", i, sep = "")]])
        list4 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = 1,
            Answer_Str = numRange,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "numericInput"
          )
        jlist[[index]] <<- list4
        Num <- append(Num, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Num <- append(Num, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", numericInput(
            paste("numericInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], value = ""
          )),
          div(class = "div inline block", imgs)
        )))
        Num <-
          append(Num, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion[[index]] <<- Num
      }
      else if (Dtype[[i]] == "TextInput") {
        Text <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list5 <-
          list(
            data_type = "non_numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = 1,
            Answer_Str = NA,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "TextInput"
          )
        jlist[[index]] <<- list5
        Text <- append(Text, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Text <- append(Text, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", textInput(
            paste("textInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], value = ""
          )),
          div(class = "div inline block", imgs)
        )))
        Text <-
          append(Text, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion[[index]] <<- Text
      }
      else if (Dtype[[i]] == "DateInput") {
        Date <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list6 <-
          list(
            data_type = "non_numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = 1,
            Answer_Str = NA,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "DateInput"
          )
        jlist[[index]] <<- list6
        Date <- append(Date, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Date <- append(Date, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", dateInput(
            paste("dateInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], value = NA
          )),
          div(class = "div inline block", imgs)
        )))
        Date <-
          append(Date, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        allQuestion[[index]] <<- Date
      }
      frage$jlistedit <- jlist
      
      frage$edit <- allQuestion
      return(allQuestion)
    }
    else{
      df3 <- read_json(inFile1$datapath)
      
      if (names(df3[i]) == "Question_checkbox") {
        a <- NULL
        checkbox <- list()
        imgs <- list()
        for (k in seq(1:rnum)) {
          a <- append(a, input[[paste("Question", i, k, "Answer", sep = "")]])
        }
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, input[[paste("sonst", i, sep = "")]])
          rnum <- rnum + 1
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list1 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = rnum,
            Answer_Str = a,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "checkboxGroupInput"
          )
        jlist[[index]] <<- list1
        checkbox <-
          append(checkbox, list(h4(paste(
            "Question", i, sep = ""
          ))))
        checkbox <-
          append(checkbox, list(tags$div(
            class = "mean-plot-row",
            div(
              class = "div box-question",
              checkboxGroupInput(paste0("Questionnbogen", i), input[[paste("Question_", i, sep = "")]], choices = a)
            ),
            div(class = "div inline block", imgs)
          )))
        checkbox <-
          append(checkbox, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire[[index]] <<- checkbox
        
      }
      else if (names(df3[i]) == "Question_RBn") {
        e <- NULL
        RBn <- list()
        imgs <- list()
        for (k in seq(1:rnum)) {
          e <- append(e, input[[paste("Question", i, k, "Answer", sep = "")]])
        }
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, input[[paste("sonst", i, sep = "")]])
          rnum <- rnum + 1
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list2 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = rnum,
            Answer_Str = e,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "radioButtons"
          )
        jlist[[index]] <<- list2
        RBn <- append(RBn, list(h4(paste(
          "Question", i, sep = ""
        ))))
        RBn <-
          append(RBn, list(tags$div(
            tags$div(
              class = "mean-plot-row",
              div(class = "div box-question", radioButtons(
                paste0("Questionnbogen", i), input[[paste("Question_", i, sep = "")]], choices = e
              )),
              div(class = "div inline block", imgs)
            )
          )))
        RBn <-
          append(RBn, list(
            div(
              style = "display:inline-block",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire[[index]] <<- RBn
      }
      else if (names(df3[i]) == "Question_Range") {
        imgs <- list()
        Range <- list()
        a <- NULL
        jnum <- input[[paste("Answernum-", i, sep = "")]]
        a <-
          append(a, input[[paste("range1", i, sep = "")]])
        if (jnum > 2) {
          jnumN <- jnum - 2
          for (k in 1:jnumN) {
            a <- append(a, "")
          }
        }
        a <-
          append(a, input[[paste("range2", i, sep = "")]])
        
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, "Other")
          jnum <- jnum + 1
        }
        
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        list0 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = jnum,
            Answer_Str = a,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "radioButton"
          )
        jlist <<-
          append(jlist, list(Question_Range = list0))
        
        Range <-
          append(Range, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Range <- append(Range, list(tags$div(
          class = "mean-plot-row",
          div(
            class = "div box-question",
            radioButtons(
              paste("Questionnbogen", i, sep = ""),
              input[[paste("Question_", i, sep = "")]],
              choices = a,
              width = "70%"
            )
          ),
          div(class = "div inline block", imgs)
        )))
        Range <-
          append(Range, list(
            tags$div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        
        Questionaire[[index]] <<- Range
      }
      else if (names(df3[i]) == "Question_Se") {
        h <- NULL
        Select <- list()
        imgs <- list()
        for (k in seq(1:rnum)) {
          h <- append(h, input[[paste("Question", i, k, "Answer", sep = "")]])
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list3 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = rnum,
            Answer_Str = h,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "selectInput"
          )
        jlist[[index]] <<- list3
        Select <-
          append(Select, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Select <-
          append(Select, list(tags$div(
            class = "mean-plot-row",
            div(class = "div box-question", selectInput(
              paste("selectInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], choices = h
            )),
            div(class = "div inline block", imgs)
          )))
        Select <-
          append(Select, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire[[index]] <<- Select
      }
      
      else if (names(df3[i]) == "Question_num") {
        Num <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        numRange <-
          append(numRange, input[[paste("range1_", i, sep = "")]])
        numRange <-
          append(numRange, input[[paste("range2_", i, sep = "")]])
        list4 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = 1,
            Answer_Str = NA,
            range = numRange,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "numericInput"
          )
        jlist[[index]] <<- list4
        Num <- append(Num, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Num <- append(Num, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", numericInput(
            paste("numericInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], value = ""
          )),
          div(class = "div inline block", imgs)
        )))
        Num <-
          append(Num, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire[[index]] <<- Num
      }
      else if (names(df3[i]) == "Question_text") {
        Text <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list5 <-
          list(
            data_type = "non_numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = 1,
            Answer_Str = NA,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "TextInput"
          )
        jlist[[index]] <<- list5
        Text <- append(Text, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Text <- append(Text, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", textInput(
            paste("textInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], value = ""
          )),
          div(class = "div inline block", imgs)
        )))
        Text <-
          append(Text, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire[[index]] <<- Text
      }
      else if (names(df3[i]) == "Question_date") {
        Date <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        list6 <-
          list(
            data_type = "non_numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = 1,
            Answer_Str = NA,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "DateInput"
          )
        jlist[[index]] <<- list6
        Date <- append(Date, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Date <- append(Date, list(tags$div(
          class = "mean-plot-row",
          div(class = "div box-question", dateInput(
            paste("dateInput", i, sep = ""), input[[paste("Question_", i, sep = "")]], value = NA
          )),
          div(class = "div inline block", imgs)
        )))
        Date <-
          append(Date, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire[[index]] <<- Date
      }
      frage$jlistedit1 <- jlist
      
      frage$edit1 <- Questionaire
      return(Questionaire)
    }
  })
  
  # list for upload Questionaire
  Questionaire <<- list()
  #################################################upload questionaire#####################################
  # upload Questionaire
  jsonQuestionaire <- reactive({
    input$okay_RBn
    input$okay_checkbox
    input$okay_TeI
    input$okay_Range
    input$okay_SeI
    input$okay_DaI
    input$okay_numI
    input$ok
    
    inFile1 <- input$new
    if (is.null(inFile1)) {
      return()
    }
    df3 <- read_json(inFile1$datapath)
    jlist <<- append(jlist, df3)
    len <- length(df3)
    for (i in seq(1:len)) {
      if (names(df3[i]) == "Question_checkbox") {
        a <- NULL
        checkbox1 <- list()
        imgs <- list()
        for (j in seq(1:df3[[i]]$Answer_nr)) {
          a <- append(a, j)
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        checkbox1 <-
          append(checkbox1, list(h4(paste(
            "Question", i, sep = ""
          ))))
        checkbox1 <-
          append(checkbox1, list(
            tags$div(
              class = "mean-plot-row",
              checkboxGroupInput(
                paste("Questionbogen", i, sep = ""),
                df3[[i]]$question_name,
                choiceNames = df3[[i]]$Answer_Str,
                choiceValues = a
              )
            )
          ))
        checkbox1 <-
          append(checkbox1, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire <<-
          append(Questionaire, list(checkbox1))
      } else if (names(df3[[i]]) == "Question_Range") {
        imgs <- list()
        Range <- list()
        a <- NULL
        jnum <- input[[paste("Answernum-", i, sep = "")]]
        a <-
          append(a, input[[paste("range1", i, sep = "")]])
        if (jnum > 2) {
          jnumN <- jnum - 2
          for (k in 1:jnumN) {
            a <- append(a, "")
          }
        }
        a <-
          append(a, input[[paste("range2", i, sep = "")]])
        
        if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
          a <- append(a, "Other")
          jnum <- jnum + 1
        }
        
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        
        list0 <-
          list(
            data_type = "numeric",
            question_name = input[[paste("Question_", i, sep = "")]],
            Answer_nr = jnum,
            Answer_Str = NULL,
            Img_Nr = nrow(inFile),
            Img_paths = nimg,
            Shiny_Widgets_type = "radioButton"
          )
        jlist <<-
          append(jlist, list(Question_Range = list0))
        
        Range <-
          append(Range, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Range <- append(Range, list(tags$div(
          class = "mean-plot-row",
          div(
            class = "div box-question",
            radioButtons(
              paste("Questionnbogen", i, sep = ""),
              input[[paste("Question_", i, sep = "")]],
              choices = a,
              width = "70%"
            )
          ),
          div(class = "div inline block", imgs)
        )))
        Range <-
          append(Range, list(
            tags$div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        
        Questionaire <<- append(Questionaire, list(Range))
      }
      else if (names(df3[i]) == "Question_RBn") {
        a <- NULL
        RBn <- list()
        imgs <- list()
        for (j in seq(1:df3[[i]]$Answer_nr)) {
          a <- append(a, j)
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        RBn <- append(RBn, list(h4(paste(
          "Question", i, sep = ""
        ))))
        RBn <- append(RBn, list(tags$div(
          class = "mean-plot-row",
          radioButtons(
            paste("Questionbogen", i, sep = ""),
            df3[[i]]$question_name,
            choiceNames = df3[[i]]$Answer_Str,
            choiceValues = a
          )
        )))
        RBn <-
          append(RBn, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire <<- append(Questionaire, list(RBn))
      }
      else if (names(df3[i]) == "Question_Se") {
        a <- NULL
        Select <- list()
        imgs <- list()
        for (j in seq(1:df3[[i]]$Answer_nr)) {
          a <- append(a, j)
        }
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Select <-
          append(Select, list(h4(paste(
            "Question", i, sep = ""
          ))))
        Select <-
          append(Select, list(tags$div(
            class = "mean-plot-row",
            selectInput(
              paste("Questionbogen", i, sep = ""),
              df3[[i]]$question_name,
              choices = df3[[i]]$Answer_Str
            )
          )))
        Select <-
          append(Select, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire  <<-
          append(Questionaire , list(Select))
      }
      else if (names(df3[i]) == "Question_num") {
        Num <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Num <- append(Num, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Num <-
          append(Num, list(tags$div(
            tags$div(
              class = "mean-plot-row",
              numericInput(
                paste("Questionbogen", i, sep = ""),
                df3[[i]]$question_name,
                min = df3[[i]]$Answer_Str[1],
                max = df3[[i]]$Answer_Str[2],
                value = ""
              )
            )
          )))
        Num <-
          append(Num, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire  <<- append(Questionaire , list(Num))
      }
      else if (names(df3[i]) == "Question_text") {
        Text <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Text <- append(Text, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Text <- append(Text, list(tags$div(
          class = "mean-plot-row",
          textInput(
            paste("Questionbogen", i, sep = ""),
            df3[[i]]$question_name,
            value = ""
          )
        )))
        Text <-
          append(Text, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire  <<- append(Questionaire , list(Text))
      }
      else if (names(df3[i]) == "Question_date") {
        Date <- list()
        imgs <- list()
        if (!is.null(inFile)) {
          for (j in seq(1:imgfiles)) {
            temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
            imgs <- append(imgs, list(tags$div(
              tags$img(src = temp, class = "img-view")
            )))
            nimg <- append(nimg, temp)
          }
        }
        Date <- append(Date, list(h4(paste(
          "Question", i, sep = ""
        ))))
        Date <- append(Date, list(tags$div(
          class = "mean-plot-row",
          dateInput(
            paste("Questionbogen", i, sep = ""),
            df3[[i]]$question_name,
            value = NA
          )
        )))
        Date <-
          append(Date, list(
            div(
              class = "div box-btn",
              actionButton(
                paste0("delete", i),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", i),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )
          ))
        Questionaire  <<- append(Questionaire , list(Date))
      }
    }
    lenButton <- input$okay_edit + input$alt
    
    if (get_okay() > lenButton) {
      length_Question = length(Dtype)
      for (i in mark_Question:length_Question)
      {
        nimg <- list()
        jnum <- input[[paste("num", i, sep = "")]]
        inFile <- input[[paste("myFile", i, sep = "")]]
        imgfiles = nrow(inFile)
        numRange <- NULL
        if (Values$Alt == 0) {
          Numlist <- i + len
        }
        else{
          Numlist <- i + len - 1
        }
        
        if (Dtype[[i]] == "checkbox") {
          a <- NULL
          checkbox <- list()
          imgs <- list()
          for (k in seq(1:jnum)) {
            a <- append(a, input[[paste("Question", i, k, "Answer", sep = "")]])
          }
          if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
            a <- append(a, input[[paste("sonst", i, sep = "")]])
            jnum  <- jnum  + 1
          }
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          list1 <-
            list(
              data_type = "numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = jnum,
              Answer_Str = a,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "checkboxGroupInput"
            )
          jlist <<-
            append(jlist, list(Question_checkbox = list1))
          checkbox <-
            append(checkbox, list(h4(
              paste("Question", Numlist, sep = "")
            )))
          checkbox <-
            append(checkbox, list(tags$div(
              class = "mean-plot-row",
              div(
                class = "div box-question",
                checkboxGroupInput(
                  paste("Questionbogen", Numlist, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  choices = a,
                  width = "70%"
                )
              ),
              div(class = "div inline block", imgs)
            )))
          checkbox <-
            append(checkbox, list(
              div(
                class = "div box-btn",
                actionButton(
                  paste0("delete", Numlist),
                  tr("Delete"),
                  icon = icon("trash"),
                  class = "btn-type btn-delete"
                ),
                actionButton(
                  paste0("edit", Numlist),
                  tr("Edit"),
                  icon = icon("pencil"),
                  class = "btn-type btn-edit"
                )
              )
            ))
          Questionaire <<-
            append(Questionaire, list(checkbox))
        }
        else if (Dtype[[i]] == "Range question") {
          imgs <- list()
          Range <- list()
          a <- NULL
          jnum <- input[[paste("Answernum-", i, sep = "")]]
          a <-
            append(a, input[[paste("range1", i, sep = "")]])
          if (jnum > 2) {
            jnumN <- jnum - 2
            for (k in 1:jnumN) {
              a <- append(a, "")
            }
          }
          a <-
            append(a, input[[paste("range2", i, sep = "")]])
          
          if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
            a <- append(a, "Other")
            jnum <- jnum + 1
          }
          
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          
          list0 <-
            list(
              data_type = "numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = jnum,
              Answer_Str = a,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "radioButton"
            )
          jlist <<-
            append(jlist, list(Question_Range = list0))
          
          Range <-
            append(Range, list(h4(paste(
              "Question", i, sep = ""
            ))))
          Range <-
            append(Range, list(tags$div(
              class = "mean-plot-row",
              div(
                class = "div box-question",
                radioButtons(
                  paste("Questionnbogen", i, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  choices = a,
                  width = "70%"
                )
              ),
              div(class = "div inline block", imgs)
            )))
          Range <-
            append(Range, list(
              tags$div(
                class = "div box-btn",
                actionButton(
                  paste0("delete", i),
                  tr("Delete"),
                  icon = icon("trash"),
                  class = "btn-type btn-delete"
                ),
                actionButton(
                  paste0("edit", i),
                  tr("Edit"),
                  icon = icon("pencil"),
                  class = "btn-type btn-edit"
                )
              )
            ))
          
          Questionaire <<- append(Questionaire, list(Range))
        }
        else if (Dtype[[i]] == "RBn") {
          e <- NULL
          RBn <- list()
          imgs <- list()
          for (k in seq(1:jnum)) {
            e <- append(e, input[[paste("Question", i, k, "Answer", sep = "")]])
          }
          if (input[[paste("sonstige", i, sep = "")]] == TRUE) {
            e <- append(e, input[[paste("sonst", i, sep = "")]])
            jnum  <- jnum  + 1
          }
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          list2 <-
            list(
              data_type = "numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = jnum,
              Answer_Str = e,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "radioButtons"
            )
          jlist <<-
            append(jlist, list(Question_RBn = list2))
          RBn <-
            append(RBn, list(h4(
              paste("Question", Numlist, sep = "")
            )))
          RBn <- append(RBn, list(tags$div(
            class = "mean-plot-row",
            div(
              class = "div box-question",
              radioButtons(
                paste0("Questionnbogen", Numlist),
                input[[paste("Question_", i, sep = "")]],
                choices = e,
                width = "70%"
              )
            ),
            div(class = "div inline block", imgs)
          )))
          RBn <-
            append(RBn, list(
              div(
                class = "div box-btn",
                actionButton(
                  paste0("delete", Numlist),
                  tr("Delete"),
                  icon = icon("trash"),
                  class = "btn-type btn-delete"
                ),
                actionButton(
                  paste0("edit", Numlist),
                  tr("Edit"),
                  icon = icon("pencil"),
                  class = "btn-type btn-edit"
                )
              )
            ))
          Questionaire <<- append(Questionaire, list(RBn))
        }
        else if (Dtype[[i]] == "SelectInput") {
          h <- NULL
          Select <- list()
          imgs <- list()
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          for (k in seq(1:jnum)) {
            h <- append(h, input[[paste("Question", i, k, "Answer", sep = "")]])
          }
          list3 <-
            list(
              data_type = "numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = jnum,
              Answer_Str = h,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "selectInput"
            )
          jlist <<- append(jlist, list(Question_Se = list3))
          Select <-
            append(Select, list(h4(
              paste("Question", Numlist, sep = "")
            )))
          Select <-
            append(Select, list(tags$div(
              class = "mean-plot-row",
              div(
                class = "div box-question",
                selectInput(
                  paste("selectInput", Numlist, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  choices = h,
                  width = "70%"
                )
              ),
              div(class = "div inline block", imgs)
            )))
          Select <-
            append(Select, list(
              div(
                class = "div box-btn",
                actionButton(
                  paste0("delete", Numlist),
                  tr("Delete"),
                  icon = icon("trash"),
                  class = "btn-type btn-delete"
                ),
                actionButton(
                  paste0("edit", Numlist),
                  tr("Edit"),
                  icon = icon("pencil"),
                  class = "btn-type btn-edit"
                )
              )
            ))
          Questionaire <<-
            append(Questionaire, list(Select))
        }
        else if (Dtype[[i]] == "NumInput") {
          Num <- list()
          imgs <- list()
          numRange <-
            append(numRange, input[[paste("range1_", i, sep = "")]])
          numRange <-
            append(numRange, input[[paste("range2_", i, sep = "")]])
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          list4 <-
            list(
              data_type = "numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = 1,
              Answer_Str = numRange,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "numericInput"
            )
          jlist <<-
            append(jlist, list(Question_num = list4))
          Num <-
            append(Num, list(h4(
              paste("Question", Numlist, sep = "")
            )))
          Num <- append(Num, list(tags$div(
            class = "mean-plot-row",
            div(
              class = "div box-question",
              numericInput(
                paste("numericInput", Numlist, sep = ""),
                input[[paste("Question_", i, sep = "")]],
                value = "",
                width = "70%"
              )
            ),
            div(class = "div inline block", imgs)
          )))
          Num <-
            append(Num, list(
              div(
                class = "div box-btn",
                actionButton(
                  paste0("delete", Numlist),
                  tr("Delete"),
                  icon = icon("trash"),
                  class = "btn-type btn-delete"
                ),
                actionButton(
                  paste0("edit", Numlist),
                  tr("Edit"),
                  icon = icon("pencil"),
                  class = "btn-type btn-edit"
                )
              )
            ))
          Questionaire <<- append(Questionaire, list(Num))
        }
        else if (Dtype[[i]] == "TextInput") {
          Text <- list()
          imgs <- list()
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          list5 <-
            list(
              data_type = "non_numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = 1,
              Answer_Str = NA,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "TextInput"
            )
          jlist <<-
            append(jlist, list(Question_text = list5))
          Text <-
            append(Text, list(h4(
              paste("Question", Numlist, sep = "")
            )))
          Text <-
            append(Text, list(tags$div(
              class = "mean-plot-row",
              div(
                class = "div box-question",
                textInput(
                  paste("textInput", Numlist, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  value = "",
                  width = "70%"
                )
              ),
              div(class = "div inline block", imgs)
            )))
          Text <-
            append(Text, list(
              div(
                class = "div box-btn",
                actionButton(
                  paste0("delete", Numlist),
                  tr("Delete"),
                  icon = icon("trash"),
                  class = "btn-type btn-delete"
                ),
                actionButton(
                  paste0("edit", Numlist),
                  tr("Edit"),
                  icon = icon("pencil"),
                  class = "btn-type btn-edit"
                )
              )
            ))
          Questionaire <<- append(Questionaire, list(Text))
        }
        else if (Dtype[[i]] == "DateInput") {
          Date <- list()
          imgs <- list()
          if (!is.null(inFile)) {
            for (j in seq(1:imgfiles)) {
              temp <- dataURI(file = inFile[[j, 'datapath']], mime = "image/png")
              imgs <- append(imgs, list(tags$div(
                tags$img(src = temp, class = "img-view")
              )))
              nimg <- append(nimg, temp)
            }
          }
          list6 <-
            list(
              data_type = "non_numeric",
              question_name = input[[paste("Question_", i, sep = "")]],
              Answer_nr = 1,
              Answer_Str = NA,
              Img_Nr = nrow(inFile),
              Img_paths = nimg,
              Shiny_Widgets_type = "DateInput"
            )
          jlist <<-
            append(jlist, list(Question_date = list6))
          Date <-
            append(Date, list(h4(
              paste("Question", Numlist, sep = "")
            )))
          Date <-
            append(Date, list(tags$div(
              class = "mean-plot-row",
              div(
                class = "box",
                dateInput(
                  paste("dateInput", Numlist, sep = ""),
                  input[[paste("Question_", i, sep = "")]],
                  value = NA,
                  width = "70%"
                )
              ),
              div(class = "div inline block", imgs)
            )))
          Date <-
            append(Date, list(div(
              class = "box",
              actionButton(
                paste0("delete", Numlist),
                tr("Delete"),
                icon = icon("trash"),
                class = "btn-type btn-delete"
              ),
              actionButton(
                paste0("edit", Numlist),
                tr("Edit"),
                icon = icon("pencil"),
                class = "btn-type btn-edit"
              )
            )))
          Questionaire <<- append(Questionaire, list(Date))
        }
      }
    }
    
    frage$before1 <- Questionaire
    frage$jlistbefore1 <- jlist
    return(Questionaire)
  })
  
  
  #Questionnbogen erstellen
  observeEvent({
    get_okay()
  }, {
    output$Fragenbogen <- renderUI({
      isolate({
        if (get_okay() == 0) {
          return(NULL)
        }
        else if (!is.null(input$new) &&
                 rv$edit == "FALSE") {
          jlist <<- NULL
          allQuestion <<- NULL
          Questionaire <<- NULL
          return(jsonQuestionaire())
        }
        else if (is.null(input$new) && rv$edit == "FALSE") {
          return(Fragenbogen())
        }
        else if (rv$edit == "TRUE") {
          return(Edit())
        }
      })
      return(NULL)
    })
  })
  
  ##################################################delete question######################################3
  # reactiveValues for delete question
  a <- reactiveValues(b = vector())
  
  # question in json file and in app delete
  observeEvent(input[[paste0("delete", rv$lastBtn)]], {
    if (is.null(input[[paste0("delete", rv$lastBtn)]]) ||
        input[[paste0("delete", rv$lastBtn)]] == 0) {
      return()
    }
    
    i <- rv$lastBtn
    
    wert <- NULL
    if (changevalue$n1 == i) {
      wert <- changevalue$n2
    }
    if (changevalue$n2 == i) {
      wert <- changevalue$n1
    }
    if (changevalue$n1 != i && changevalue$n2 != i) {
      wert <- i
    }
    a$b <- append(a$b, wert)
    sort(unlist(a$b))
    output$Fragenbogen <- renderUI({
      if (is.null(input$new)) {
        if (input$change1 == 0 && input$okay_edit == 0) {
          allQuestion <<- frage$before[-a$b]
          jlist <<- frage$jlistbefore[-a$b]
        }
        else if (input$change1 != 0 &&
                 input$okay_edit == 0) {
          allQuestion <<- frage$change[-a$b]
          jlist <<- frage$jlistchange[-a$b]
        }
        else if (input$okay_edit != 0 &&
                 input$change1 == 0) {
          allQuestion <<- frage$edit[-a$b]
          jlist <<- frage$jlistedit[-a$b]
        }
        return(allQuestion)
      }
      else if (!is.null(input$new)) {
        if (input$change1 == 0 && input$okay_edit == 0) {
          Questionaire <<- frage$before1[-a$b]
          jlist <<- frage$jlistbefore1[-a$b]
        }
        else if (input$change1 != 0 &&
                 input$okay_edit == 0) {
          Questionaire <<- frage$change1[-a$b]
          jlist <<- frage$jlistchange1[-a$b]
        } else if (input$okay_edit != 0 &&
                   input$change1 != 0) {
          Questionaire <<- frage$edit1[-a$b]
          jlist <<- frage$jlistedit1[-a$b]
        }
        return(Questionaire)
      }
    })
    return(NULL)
  })
  
  # list change
  list_change <- function(x, a, b) {
    if (a > 0 && b > 0) {
      temp <- NULL
      temp = x[[a]]
      x[[a]] = x[[b]]
      x[[b]] = temp
      return(x)
    }
    else{
      return(NULL)
    }
  }
  changevalue <- reactiveValues(n1 = 0, n2 = 0)
  
  # question list change
  observeEvent({
    input$change1
  }, {
    if (is.null(input$change1) || input$change1 == 0) {
      return()
    }
    i <- input$Snum1
    j <- input$Snum2
    changevalue$n1 <- i
    changevalue$n2 <- j
    output$Fragenbogen <- renderUI({
      if (i > 0 &&
          j > 0 &&
          i <= length(allQuestion) &&
          j <= length(allQuestion) && is.null(input$new)) {
        allQuestion <<- list_change(allQuestion, i, j)
        jlist <<- list_change(jlist, i, j)
        names(jlist) <<- list_change(names(jlist), i, j)
        frage$change <- allQuestion
        frage$jlistchange <- jlist
        return(allQuestion)
      }
      else if (i <= 0 ||
               j <= 0 ||
               i > length(allQuestion) ||
               j > length(allQuestion) &&
               is.null(input$new)) {
        isolate(showModal(modalDialog(
          tr("Irregular input or wrong input")
        )))
        return(allQuestion)
      }
      else if (i > 0 &&
               j > 0 &&
               i <= length(Questionaire) &&
               j <= length(Questionaire) &&
               !is.null(input$new)) {
        Questionaire <<- list_change(Questionaire, i, j)
        jlist <<- list_change(jlist, i, j)
        names(jlist) <<- list_change(names(jlist), i, j)
        frage$change1 <- Questionaire
        frage$jlistchange1 <- jlist
        return(Questionaire)
      }
      else if (i <= 0 ||
               j <= 0 ||
               i > length(Questionaire) ||
               j > length(Questionaire) &&
               !is.null(input$new)) {
        isolate(showModal(modalDialog(
          tr("Irregular input or wrong input")
        )))
        return(Questionaire)
      }
    })
    return(NULL)
  })
  
  jsonname <- reactiveValues()
  time <- Sys.time()
  date = format(time, "%Y-%m-%d-%H-%M-%S")
  jsonname <- paste0("template_", date, ".json")
  
  # save the Questionnbogen
  output$Save <- downloadHandler(
    filename = function() {
      jsonname
    },
    content = function(file1) {
      exportJSON <- toJSON(jlist)
      write(exportJSON, file1)
    }
  )
  
}
