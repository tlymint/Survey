fluidRow(
  column(width = 2),
  column(width = 8,
         div(class = "extract-row",
             h2(tr("Pain2D-Survey"),class = "modal-title"),
             tags$hr(class = "hr"),
             tags$head(
               tags$style(HTML('#NFile{custom-file-upload}'))
             ),
             fileInput("NFile",tr("Please select the Questionnaire"),
                       accept = c(".json"),multiple = FALSE,placeholder = tr("No file selected")),
             actionLink("make",tr("Is there no existing questionnaire? Then make a questionnaire!!!"),class = "link"),
             tags$br(),
             actionLink("evalute",tr("questionnaire evalute"),class = "link"),
             # actionButton("make","make"),
             # actionButton("view","view"),
             # actionButton("evalute","evalute"),
             tags$br(),
             actionButton("start",tr("Start"))
             
             ))
)

