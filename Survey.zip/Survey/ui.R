library(shiny)
library(shinyWidgets)
library(shiny.i18n)
library(ggplot2)
library(shinyjs)

i18n <- Translator$new(translation_json_path = "translation.json")

shinyUI(
  tagList(
    shiny.i18n::usei18n(i18n),
    useShinyjs(),
    includeCSS("www/bootstrap.css"),
    tags$link(href = "https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;800;900&display=swap", rel =
                "stylesheet"),
    column(
      1,
      tags$img(src = "TC-survey Logo.png", style = "width:200px;height:200px")
    ),
    
    column(
      10,
      navbarPage(
        title = "",
        id = "navbar",
        tabPanel(
          title = "make",
          "",
          column(
            width = 2,
            div(
              class = "mean-row",
              h1(i18n$t("Choose questionaire element"), class = "modal-title"),
              tags$hr(class = "div hr"),
              actionButton("checkbox", i18n$t("Multiple choice"), class = "btn-type btn-checkbox"),
              tags$br(),
              tags$br(),
              actionButton("FA", i18n$t("Range"), class = "btn-type btn-forDoctor"),
              tags$br(),
              tags$br(),
              actionButton("RBn", i18n$t("Single choice"), class = "btn-type btn-radioButton"),
              tags$br(),
              tags$br(),
              actionButton("numI", i18n$t("Number"), class = "btn-type btn-num"),
              tags$br(),
              tags$br(),
              actionButton("TeI", i18n$t("Text"), class = "btn-type btn-text"),
              tags$br(),
              tags$br(),
              actionButton("DaI", i18n$t("Date"), class = "btn-type btn-date"),
              tags$br(),
              tags$br(),
              actionButton("SeI", i18n$t("Select"), class = "btn-type btn-select"),
              tags$br(),
              tags$br(),
              actionButton("LK", i18n$t("Linkage"), class = "btn-type btn-Linkage"),
              tags$br(),
              tags$br(),
              actionButton("GR", i18n$t("Group"), class = "btn-type btn-group")
            )
          ),
          column(
            width = 5,
            div(
              class = "mean-make-middle-row",
              uiOutput("Erstellen"),
              uiOutput("Answer"),
              tags$br(),
              useShinyjs(),
              conditionalPanel(
                condition = "input.checkbox != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_checkbox",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.RBn != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_RBn",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.numI != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_numI",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.TeI != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_TeI",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.DaI != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_DaI",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.SeI != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_SeI",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.FA != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_Range",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.LK != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_LK",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              conditionalPanel(
                condition = "input.GR != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_Group",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                ),
              ),
              
              conditionalPanel(
                condition = "input.okay_checkbox != 0 || input.okay_RBn != 0 || input.okay_numI !=0 || input.okay_TeI != 0 || input.okay_DaI != 0 || input.okay_SeI != 0 || input.okay_Range != 0 ||input.alt != 0 ||input.okay_LK != 0 ||input.okay_Group != 0",
                tags$button(
                  i18n$t("create question"),
                  id = "okay_edit",
                  type = "button",
                  class = "btn btn-danger action-button btn-type btn-create"
                )
              )
            )
          ),
          
          column(
            width = 5,
            div(
              class = "mean-right-row",
              h1(i18n$t("Questionnaire template"), class = "modal-title"),
              tags$hr(class = "div hr"),
              useShinyjs(),
              h3(
                i18n$t("Please enter the two question numbers to be exchanged: "),
                align = "right"
              ),
              div(style = "display:inline-block;width: 100px"),
              div(
                style = "display:inline-block;width: 100px",
                numericInput(
                  "Snum1",
                  "Q1",
                  "0",
                  min = 1,
                  max = length(allQuestion),
                  width = "50%"
                )
              ),
              div(
                style = "display:inline-block;width: 100px",
                numericInput(
                  "Snum2",
                  "Q2",
                  "0",
                  min = 1,
                  max = length(allQuestion),
                  width = "50%"
                )
              ),
              div(
                style = "display:inline-block;width: ",
                actionButton(
                  "change1",
                  i18n$t("Change"),
                  icon = icon("sort"),
                  class = "btn-type btn-change"
                )
              ),
              tags$hr(class = "div hr"),
              tags$br(),
              div(
                style = "display:inline-flex;",
                fileInput(
                  "new",
                  i18n$t("Upload Questionaire"),
                  accept = c(
                    "application/json",
                    "text/comma-separated-values,text/plain",
                    ".json"
                  ),
                  multiple = FALSE,
                  placeholder = i18n$t("No file selected")
                ),
                div(
                  style = "margin-top:18px;margin-left:20px",
                  actionButton(
                    "alt",
                    i18n$t("Upload"),
                    icon = icon("upload"),
                    width = "100%",
                    class = "btn-type btn-upload"
                  )
                )
              ),
              tags$br(),
              div(
                style = "display:inline-block;width:200px",
                downloadButton("Save", i18n$t("Save"), class = "btn-type btn-save")
              ),
              #div(style="display:inline-block;", actionButton("pdfgenerator","PDF",class = "btn-type btn-save")),
              div(
                style = "display:inline-block;",
                actionButton("sdaps", "PDF", class = "btn-type btn-save")
              ),
              tags$br(),
              div(
                style = "display:inline-block;",
                actionButton("sdap", "Sdaps", class = "btn-type btn-save")
              ),
              tags$hr(class = "div hr"),
              uiOutput("Fragenbogen"),
              tags$hr(class = "div hr"),
              uiOutput("pdfviewer"),
              tags$br(),
              
            )
            
          )
        ),
        tabPanel(
          title = "view",
          "",
          fluidRow(
            useShinyjs(),
            column(width = 2),
            column(
              width = 8,
              div(
                class = "mean-view",
                tags$head(tags$style(HTML(
                  '#NFile{custom-file-upload}'
                ))),
                fileInput(
                  "NFile1",
                  i18n$t("Please select the Questionnaire"),
                  accept = c(".json"),
                  multiple = FALSE
                ),
                # checkboxGroupInput("confirm",i18n$t("Thank you for taking time to participate in this survey.All findings are fully confidential and anonymous."),choices = i18n$t("yes.i agree")),
                
                uiOutput("Q2"),
                uiOutput("other"),
                uiOutput("number")
              )
            ),
            
            fluidRow(
              column(width = 4,
                     useShinyjs(),),
              useShinyjs(),
              column(
                4,
                actionButton(
                  "go",
                  "",
                  icon("arrow-right"),
                  width = "150px",
                  class = "btn btn-danger action-button btn-type btn-go"
                )
              )
            ),
            fluidRow(
              column(
                width = 1,
                conditionalPanel(
                  condition = "input.go >= 1",
                  downloadButton("Nsave", "save", class = "btn-type butt1")
                )
              ),
              column(
                width = 1,
                conditionalPanel(
                  condition = "input.go >= 1",
                  actionButton("cancel", i18n$t("Cancel"), icon("remove"), class = "btn-type btn-cancel")
                )
              )
            )
          )
          
        ),
        tabPanel(title = "evalute", "",
                 fluidRow(
                   column(
                     width = 3,
                     div(
                       class = "mean-row",
                       #tags$button(i18n$t("Back"),id = "back",type = "button",class = "btn btn-danger action-button glyphicon glyphicon-triangle-left",class = "btn-type btn-back"),
                       #tags$br(),
                       #tags$hr(class = "div hr"),
                       fileInput(
                         "file",
                         i18n$t("Please select the data of Questionnaire"),
                         accept = c("text/csv",
                                    "text/comma-separated-values,text/plain",
                                    ".csv"),
                         multiple = TRUE
                       ),
                       tags$hr(style = "border: 1px solid #CBDCE7"),
                       fileInput(
                         "file2",
                         i18n$t("Please select the Questionnaire"),
                         accept = c(
                           "application/json",
                           "text/comma-separated-values,text/plain",
                           ".json"
                         ),
                         multiple = FALSE
                       ),
                       
                       tags$hr(class = "div hr"),
                       tags$br(),
                       tags$br(),
                       uiOutput("TypeQuestion"),
                       downloadButton("download", i18n$t("Download"), class = "btn-type butt"),
                       tags$br(),
                       tags$br(),
                       downloadButton("downloadAll", i18n$t("DownloadAll"), class = "btn-type butt")
                     )
                   ),
                   column(width = 9, div(class = "mean-row",
                                         uiOutput("AllTabelle")))
                 ))
      )
    ),
    column(1, style = "position:relative; margin-top:2%;",
           tabsetPanel(
             id = "language",
             tabPanel("EN", value = "en"),
             tabPanel("DE", value = "de")
           ))
  )
)
