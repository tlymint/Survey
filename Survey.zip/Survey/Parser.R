library(jsonlite)
library(readtext)

Questions_Fabrik <- function(questionaire_JSON,name,author){
  #browser()
  
  if(is.null(name)){name <- "The Author"}
  if(is.null(author)){name <- "The Title"}
  
  questions_for_SDAPS <- paste0("\\author{",name,"}\n", "\\title{",name,"}\n","\\begin{document}\n",
  "% Everything you do should be done inside the questionnaire environment.
  % If you don't like the default text at the beginning of each questionnaire
  % you can remove it with the optional [noinfo] parameter for the environment 
  \\begin{questionnaire}")
  
  for (i in seq(1:length(questionaire_JSON))){
   # browser()
  if(names(questionaire_JSON[i]) == "Question_RBn"){
    RBtn <- questionaire_JSON[[i]]
    if(RBtn$data_type == "numeric"){
      questions_for_SDAPS <- append(questions_for_SDAPS,
        paste0("\\begin{optionquestion}[cols=", 
               1,
               ",singlechoice]\n{", 
               RBtn$question_name ,
               "}", 
              Generate_answerList(RBtn), "\\end{optionquestion}\n"
              ))
    }
    
    lenA <- RBtn$Answer_nr
    for(i in seq(1:lenA)){
      if(!is.null(RBtn$Answer_Str[i]$Answer$Image$path)){
        questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(RBtn)))
      }
    }
    }
    else if(names(questionaire_JSON[i]) == "Question_Select"){
      Selectn <- questionaire_JSON[[i]]
      if(Selectn$data_type == "numeric"){
        questions_for_SDAPS <- append(questions_for_SDAPS,
                                      paste0("\\begin{optionquestion}[cols=", 
                                             2,
                                             ",singlechoice]\n{", 
                                             Selectn$question_name ,
                                             "}", 
                                             Generate_answerList(Selectn), "\\end{optionquestion}\n"
                                      ))
      }
      lenA <- Selectn$Answer_nr
      for(i in seq(1:lenA)){
        if(!is.null(Selectn$Answer_Str[i]$Answer$Image$path)){
          questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(Selectn)))
        }
      }
    }
  else if(names(questionaire_JSON[i]) == "Question_checkbox"){
    checkboxn <- questionaire_JSON[[i]]
    if(checkboxn$data_type=="numeric"){
      questions_for_SDAPS <- append(questions_for_SDAPS,
        paste0("\\begin{choicequestion}[cols=", 
               1,
               "]{", 
               checkboxn$question_name ,
               "}\n", 
               Generate_answerList(checkboxn), "\\end{choicequestion}\n"
        ))
    }
    lenA <- checkboxn$Answer_nr
    for(i in seq(1:lenA)){
      if(!is.null(checkboxn$Answer_Str[i]$Answer$Image$path)){
        questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(checkboxn)))
      }
    }
  }
  else if(names(questionaire_JSON[i]) == "Question_text" || names(questionaire_JSON[i]) == "Question_num"){
    textn <- questionaire_JSON[[i]]
    if(textn$data_type=="non_numeric"){
      questions_for_SDAPS <- append(questions_for_SDAPS,
        paste0("\\textbox*{", 
               2,
               "cm}{", 
               textn$question_name,
               "}\n"
      
        ))
    }
    lenA <- textn$Answer_nr
    if(!is.null(lenA)){
    for(i in seq(1:lenA)){
      if(!is.null(textn$Answer_Str[i]$Answer$Image$path)){
        questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(textn)))
      }
    }
    }
   # questions_for_SDAPS <- append(questions_for_SDAPS,paste0("\\begin{figure}[here]",Generate_imageList(textn),"\\end{figure}\n"))
  }
  else if(names(questionaire_JSON[i]) == "Question_Range"){
    rangen <- questionaire_JSON[[i]]
    if(rangen$data_type=="numeric"){
      if("Other" %in% rangen$Answer_Str[]){
        questions_for_SDAPS <- append(questions_for_SDAPS,
                                      paste0("\\singlemarkother[count=",rangen$Answer_nr,"]{", 
                                             rangen$question_name,
                                             "}{",rangen$Answer_Str[[1]],"}{",rangen$Answer_Str[[2]],"}{other}\n"
                                      ))
      }
      else{
      questions_for_SDAPS <- append(questions_for_SDAPS,
        paste0("\\singlemark[count=",rangen$Answer_nr,"]{", 
               rangen$question_name,
               "}{",rangen$Answer_Str[[1]],"}{",rangen$Answer_Str[[2]],"}\n"
        ))}
    }
    lenA <- rangen$Answer_nr
    for(i in seq(1:lenA)){
      if(!is.null(rangen$Answer_Str[i]$Answer$Image$path)){
        questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(rangen)))
      }
    }
    #questions_for_SDAPS <- append(questions_for_SDAPS,paste0("\\begin{figure}[here]",Generate_imageList(rangen),"\\end{figure}\n"))
  }
    ###########################################################################group problem#####################################
    else if(names(questionaire_JSON[i]) == "Question_Group"){
      Groupn <- questionaire_JSON[i]
      if(Groupn$Question_Group$Subquestion$Shiny_Widgets_type == "checkboxGroupInput"){
          questions_for_SDAPS <- append(questions_for_SDAPS,
                                        paste0("\\begin{choicegroup}{",Groupn$Question_Group$name,"}\n",
                                               Generate_answergroupList(Groupn),
                                               Generate_questiongroupList(Groupn),
                                               "\\end{choicegroup}\n"
                                        ))
      }
      else if(Groupn$Question_Group$Subquestion$Shiny_Widgets_type=="radioButtons"){
        questions_for_SDAPS <- append(questions_for_SDAPS,
                                      paste0("\\begin{optiongroup}{",Groupn$Question_Group$name,"}\n",
                                             Generate_answergroupList(Groupn),
                                             Generate_questiongroupList(Groupn),
                                             "\\end{optiongroup}\n"
                                      ))
      }
      else if(Groupn$Question_Group$Subquestion$Shiny_Widgets_type=="Range-radioButtons"){
        questions_for_SDAPS <- append(questions_for_SDAPS,
                                      paste0("\\begin{markgroup}{",Groupn$Question_Group$name,"}\n",
                                             Generate_answergroupList(Groupn),
                                             "\\end{markgroup}\n"
                                      ))
      }
      
      #questions_for_SDAPS <- append(questions_for_SDAPS,paste0("\\begin{figure}[here]",Generate_imageList(Groupn$Question_Group$Subquestion),"\\end{figure}\n"))
    }
  
  else if(names(questionaire_JSON[i]) == "Question_date"){
    daten <- questionaire_JSON[[i]]
    if(daten$data_type=="non_numeric"){
      questions_for_SDAPS <- append(questions_for_SDAPS,
        paste0("\\begin{choicegroup}[colsep = 2pt,singlechoice]{", 
                daten$question_name,
               "}\n",
              "\\groupaddchoice{1}\n",
  "\\groupaddchoice{2}\n",
  "\\groupaddchoice{3}\n",
  "\\groupaddchoice{4}\n",
  "\\groupaddchoice{5}\n",
  "\\groupaddchoice{6}\n",
  "\\groupaddchoice{7}\n",
  "\\groupaddchoice{8}\n",
  "\\groupaddchoice{9}\n",
  "\\groupaddchoice{10}\n",
  "\\groupaddchoice{11}\n",
  "\\groupaddchoice{12}\n",
  "\\groupaddchoice{13}\n",
  "\\groupaddchoice{14}\n",
  "\\groupaddchoice{15}\n",
  "\\groupaddchoice{16}\n",
  "\\groupaddchoice{17}\n",
  "\\groupaddchoice{19}\n",
  "\\groupaddchoice{20}\n",
  "\\groupaddchoice{21}\n",
  "\\groupaddchoice{22}\n",
  "\\groupaddchoice{23}\n",
  "\\groupaddchoice{24}\n",
  "\\groupaddchoice{25}\n",
  "\\groupaddchoice{26}\n",
  "\\groupaddchoice{27}\n",
  "\\groupaddchoice{28}\n",
  "\\groupaddchoice{29}\n",
  "\\groupaddchoice{30}\n",
  "\\groupaddchoice{31}\n",
  "\\question{Day}\n",
  "\\question[range={...,12}]{Month}\n",
  "\\question[range={2,5,...,9,28,...}]{Range}\n",
"\\end{choicegroup}"
        ))
    }
    
   # questions_for_SDAPS <- append(questions_for_SDAPS,paste0("\\begin{figure}[here]",Generate_imageList(daten),"\\end{figure}\n"))
  }
  }
  
 create_Questionaire_SDAPS(questions_for_SDAPS)
  }
  
Generate_answergroupList <- function(answer){
  #browser()
    temp <- c()
    lenA <- answer$Question_Group$Subquestion$Answer_nr
    lenQ <- length(answer$Question_Group$Subquestion$question_name)
      if(answer$Question_Group$Subquestion$Shiny_Widgets_type == "checkboxGroupInput"){
        for(i in seq(1:lenA)){
        temp <- c(temp, paste0(
          "\\choice{",answer$Question_Group$Subquestion$Answer_Str[i],"}\n"
        ))
        if(!is.null(answer$Answer_Str[i]$Answer$Image$path)){
          questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(answer)))
        }
        }
      }
      else if(answer$Question_Group$Subquestion$Shiny_Widgets_type == "radioButtons"){
        for(i in seq(1:lenA)){
          temp <- c(temp, paste0(
            "\\choice{",answer$Question_Group$Subquestion$Answer_Str[i],"}\n"
          ))
          if(!is.null(answer$Answer_Str[i]$Answer$Image$path)){
            questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(answer)))
          }
        }
      }
      else if(answer$Question_Group$Subquestion$Shiny_Widgets_type == "Range-radioButtons"){
        for(i in seq(1:lenA)){
          temp <- c(temp, paste0(
            "\\markline{",answer$Question_Group$Subquestion$question_name[[i]],"}",
            "{",answer$Question_Group$Subquestion$Answer_Str[1],"}",
            "{",answer$Question_Group$Subquestion$Answer_Str[2],"}\n"
          ))
          if(!is.null(answer$Answer_Str[i]$Answer$Image$path)){
            questions_for_SDAPS <- append(questions_for_SDAPS,paste0(Generate_imageList(answer)))
          }
        }
      }
    return(paste0(temp,collapse = ""))
}

Generate_questiongroupList <- function(question){
  temp <- c()
  lenA <- question$Question_Group$Subquestion$Answer_nr
  lenQ <- length(question$Question_Group$Subquestion$question_name)
  if(question$Question_Group$Subquestion$Shiny_Widgets_type=="checkboxGroupInput"){
    for(i in seq(1:lenA)){
      temp <- c(temp, paste0(
        "\\question{",question$Question_Group$Subquestion$question_name[[i]],"}\n"
      ))
    }
  }
  else if(question$Question_Group$Subquestion$Shiny_Widgets_type=="radioButtons"){
    for(i in seq(1:lenA)){
      temp <- c(temp, paste0(
        "\\question{",question$Question_Group$Subquestion$question_name[[i]],"}\n"
      ))
    }
  }
  return(paste0(temp,collapse = ""))
}

Generate_answerList <- function(answer){
  temp <- c()
  len <- answer$Answer_nr
  #browser()
  for(i in seq(1:len)){
    if(answer$Answer_Str[i]$Answer$Answer_name == "Sonstiges"){
      temp <- c(temp, paste0(
        "\\choiceitemtext{1.2cm}{3}{Other:}\n"
      ))
    }else{
      temp <- c(temp, paste0(
        "\\choiceitem{", answer$Answer_Str[i]$Answer$Answer_name,"}\n"
      ))
    }
  }
  return(paste0(temp,collapse = ""))
}


Generate_imageList <- function(image){
  tempimg <- c()
      lenA <- image$Answer_nr
      for(i in seq(1:lenA)){
      tempimg <- c(tempimg, paste0(image$Answer_Str[i]$Answer$Image$info,
        "\\raisebox{-0.8cm}{\\includegraphics[width=",as.numeric(image$Answer_Str[i]$Answer$Image$size[[1]])*0.026,
        "cm]{",getwd(),"/www/",basename(image$Answer_Str[i]$Answer$Image$path),"}}\n"
      ))
      }
  return(paste0(tempimg,collapse = ""))
}

create_Questionaire_SDAPS <- function(questionaire_list){
  head <- readtext(file = "Template/head_questionairie.txt")[[2]]
  tail <- readtext(file = "Template/tail_questionairie.txt")[[2]]
  fileConn<-file("Template/project_example/Template_for_SDAPS.tex")
  writeLines(c(head, questionaire_list, tail), fileConn)
  close(fileConn)
}

### Test

#test.data <- read_json("Template/template_2021-04-25.json",simplifyVector = FALSE)
#Questions_Fabrik(test.data,"tly","tly")

#browser()
