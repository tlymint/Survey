Fname <- stringi::stri_extract_first(str = inFile1$name, regex = ".*(?=\\.)")
fluidRow(
  h1(div(tr("Questionaire App"),img(src="back.PNG", width = "10%", height = "10%"),align = "center",style = "h1;font-size:150")),
  column(width = 2,
         tags$button(tr("back"),id = "back2",type = "button",class = "btn btn-danger action-button glyphicon glyphicon-triangle-left btn-type btn-back",onclick="history.go(0)")),
  column(width = 8,div(class = "div viewbox",
                       if(Fname == "Default_PainDetect_Questionaire"){
                         tagList(h1(tr("Neuropathic pain:")),
                                 plotOutput("plot1",width = "100%",height = "60%"))}
                       
                       else{
                         tagList(h1(tr("Questionnaire is finished")),
                                 tags$img(src = "finish.png",height = "80%",width = "40%"))
                       }
  )),
  
  fluidRow(
    column(width = 3,
           downloadButton("Nsave",tr("save"),class= "btn-type butt"),
           # tags$head(tags$style(".butt{background-color:#f3f3f3;border-color:#000;width: 150px;height: 50px;margin-left: 700px;margin-top: 10px;font-size:150%} .butt{color: #337ab7;}"))
    ),
    column(2,actionButton("cancel",tr("cancel"),icon("remove"),style = "margin-left:600px",class = "btn-type btn-cancel"))),
  
)
