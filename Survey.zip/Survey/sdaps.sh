#!/bin/bash

sdaps setup tex /tmp/project example.tex

sdaps recognize /tmp/project

sdaps gui /tmp/project